http://forum.antp.be/phpbb2/viewtopic.php?p=2821#2821

1/ A template designed to be viewed on a TV (big letters, dark non-smeering colors)... and to be VERY easily edited to change colors, language, etc... (edit the CSS file)

1.1/ HTML File (to be used as indiv in AMC) : myAMC indiv.html

You need to get some gif with filename ratingX.gif (X from 0 to 10) from another template.

1.2/ CSS file (to be copied into your target directory for exporting) : myAMC.css

2/ Here is a template to generate a metadata file for myHTPC : myAMC full.html

To use it :
-Export under the name myAMC.html.
-Rename the generated myAMC.html to myAMC.my.
-In myHTPC, create a new Media.
-General tab : grouping method=single metadata file, filename=c:\path\myAMC.my, uncheck ALL cache settings, play with other settings as you wish.
-Player : Excecutable=c:\whateverpath\iexplorer.exe, parameters=-k, Current dir=where you exported your catalog

It displays the whole movie database in myHTPC, allowing to sort by country, director, genre, etc. A click on "play" pops up Explorer with indiv template and all details about the movie in kiosk mode (no borders, ctrl-W to close, up/down arrows to scroll, alt-left/right arrows to go back/forward).
A click on the picture launch the associated URL on the internet. If no URL is available it will display windows files (!), sorry it's not very clean, just close the window with ctrl-W.

Enjoy!