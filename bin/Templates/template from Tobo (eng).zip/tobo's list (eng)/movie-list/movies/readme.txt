In this folder, the individual pages should be placed.

Check out that the files are named:
movie_1, movie_2 and so on, when you have export.

If the files aren't named as above, you have to do some changes in the preferences.
In Tools->Preferences, you should have this option:
Export->Individual pages and pictures filename style->Exported filename + Movie number

If you have this option marked, the files will be named as above...


/Tobo