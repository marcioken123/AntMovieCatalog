Use the files "full" and "individual" in the folder "templates" when you export to HTML.

Export "full" in the folder movie-list/site and overwrite the file "list.html".
This template creates the list in the left frame.

Export "individual" in the folder movie-list/movies and save as "movie". It's important
that you export the individual template as "movie". Otherwhise, it won't work.

Go to the "movie" folder and check out that the files in the folder are named:
movie_1, movie_2 and so on, when you have export.

If the files aren't named as above, you have to do some changes in the preferences.
In Tools->Preferences, you should have this option:
Export->Individual pages and pictures filename style->Exported filename + Movie number

If you have this option marked, the files will be named as above...


To open your movie list, just open movie-list/index.html




/Tobo