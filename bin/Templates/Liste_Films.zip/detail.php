<html><head>
<link href="style.css" rel="stylesheet" type="text/css" />
<title>Fiche film</title></head>
<body>
<div align="center"><h2>Fiche film</h2></div>
<table class="blk" border="1" cellspacing="0" cellpadding="5">
<?php
$id=$_GET['id']; //champ Number
include("inc.config.php");
$requete = "SELECT `*` FROM `divx` WHERE Number='$id'";
$result = mysql_query($requete, $interne) or die(mysql_error());
$num = mysql_num_fields($result);
$row = mysql_fetch_assoc($result);
?>
  <tr>
    <td>R�f. : <strong>DX<?php echo $row['Number']; ?></strong> (<?php echo $row['Disks']; ?> CD)</td>
    <td colspan="2"><strong>
    <?php 
    if($row['Media']==""){
    	echo $row['TranslatedTitle'];
    }else{
    	echo "<a href=\"http://www.allocine.fr/film/fichefilm_gen_cfilm=".$row['Media'].".html\" 
      target=_blank>".$row['TranslatedTitle']."</a>";
    }
    ?>
    </strong><?php 
    if(strtolower($row['OriginalTitle'])!=strtolower($row['TranslatedTitle'])){
    	echo " (Titre original : ".$row['OriginalTitle'].")"; 
    }
    ?></td>
  </tr>
  <tr>
    <td rowspan="6"><div align="center"><?php 
if($row['Rating']>0){
	$i=floor(($row['Rating']-1)/2);
	echo "<img src=\"ico/appr$i.gif\" alt=\"Qualit� de l'image et du son\">";
}
?></div><br><?php if($row['Picture']!=""){echo " <img src=\"images/".$row['Picture']."\"> ";} ?>
    <br>Format : <?php echo $row['VideoFormat']; ?><br>Dur�e : <?php echo $row['Length']; ?> min.</td>
    <td>Genre : </td>
    <td><?php echo $row['Category']; ?>&nbsp;</td>
  </tr>
  <tr>
    <td>Origine : </td>
    <td><?php echo $row['Country']; ?>&nbsp;</td>
  </tr>
  <tr>
    <td>Acteurs : </td>
    <td><?php echo $row['Actors']; ?>&nbsp;</td>
  </tr>
  <tr>
    <td>R�alisateur(s) : </td>
    <td><?php echo $row['Director']; ?>&nbsp;</td>
  </tr>
  <tr>
    <td colspan="2" rowspan="2"><i><?php echo $row['Comments']; ?></i><?php echo str_replace("|", "<br>", $row['Description']); ?><br><a href="<?php echo $row['Url']; ?>" target="_blank"><?php echo $row['Url']; ?></a>&nbsp;</td>
  </tr>
</table></body></html>