<?php
/*          SCRIPT FAIT PAR Antoine Rousseau          */
/*               mouton_85@hotmail.com                */
/*----------------------------------------------------*/


/*---------------------  CONFIGURATION  --------------------*/

$hostname = "127.0.0.1"; //mettez ici le serveur MySQL (souvent 'localhost')
$username = "root"; //login et...
$password = "";     //...mot de passe de la base
$database = "test"; //mettez ici le nom de votre base
$table = "divx"; //nom de la table mysql, d�fini lors de l'exportation dans AMC

$file = "divx.xml"; //votre fichier AMC au format XML

$vous = "mOut"; //votre nom/pseudo
$titre = "mOut :: Liste de films"; //le titre de votre liste
$votresite = "http://moutonproductions.free.fr"; //url de votre site
$soustitre = "<b>Avertissement : </b>cette liste est r�serv�e � mes amis/famille, et ne constitue en aucun cas un
quelconque commerce."; //sous-titre
$contact = "mailto:mouton_85@hotmail.com"; //lien pour vous contacter (si adresse mail, rajouter "mailto:" devant (ex: mailto:moi@monisp.com))
$dest_form = "http://www.quick-web.com/web2mail/?login=antoine129"; //page de traitement du formulaire (envoy� par POST)

/*---------------------  NE PAS TOUCHER  -------------------*/

$file = "images/".$file;

$interne = mysql_pconnect($hostname, $username, $password) or die(mysql_error());
mysql_select_db($database, $interne);

?>