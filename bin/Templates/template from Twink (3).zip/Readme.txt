Twinks Template for AMC
BETA 0.7

Copy to Templates Directory
* template from Twink(2).html

COPY TO EXPORT DIRECTORY (where the final html file is)
* picBlank.gif
* nopic.gif
* /themes/*
* layoutX.xml (where X is 1 to 3)
* apprX.gif  (Where X is 0 to 5)