<?php

session_start();

/**
 * search.php
 *
 * displays the search frame
 *
 * changes:
 *	- 07 Aug 03: initial version
 */

include('settings.php');
include('language_'.$_SESSION['currentLanguage'].'.php');

?>

<html>
<head>
	<link rel="stylesheet" type="text/css" href="css/styles.css">
</head>
<body bgcolor="#FFFFFF">
	<table width="120" height="120" valign="center" border="0" cellpadding="0" cellspacing="0">
		<tr>
 			<td bgcolor="#00D0FF"><div class="head"><?php print res_SEARCH;?></div>
			</td>
		</tr>
		<tr>
 			<td bgcolor="#EFEFEF" align="justify"><div class="smalltext"><?php print res_SEARCH_ACTORS_DIRECTORS_AND_TITLES; ?></div>
			</td>
		</tr>
		<tr>
 			<td bgcolor="#EFEFEF" align="center">
			<form action="main.php" method="GET" target="main">
				<input type="hidden" name="page" value="2">
				<input type="hidden" name="field" value="all">
				<input type="Text" name="filter" value="" size="10" maxlength="100">
				<input type="Submit" name="submitSearch" value="ok">
			</form>
 			</td>
		</tr>
	</table>
</body>