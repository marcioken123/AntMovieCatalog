<?php

session_start();

/**
 * categories.php
 *
 * displays the category list in the lower left frame
 *
 * changes:
 *	- 07 Aug 03: initial version
 */

include('settings.php');
include('language_'.$_SESSION['currentLanguage'].'.php');

?>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="css/styles.css">
</head>
<body bgcolor="#FFFFFF">
<?php
if (!isset($_SESSION['categoryList'])) {
	print "\t<div class=\"normaltext\">";
	print res_LOADING;
	print "...</div>\n";
	print "\t<meta http-equiv=\"refresh\" content=\"2; URL=categories.php\">\n";
	print "</body>";
} else
{
?>
	<table width="120" valign="center" border="0" cellpadding="0" cellspacing="0">
		<tr>
			<td bgcolor="#00D0FF"><div class="head"><?php print res_CATEGORIES; ?></div>
			</td>
		</tr>
		<tr>
			<td bgcolor="#EFEFEF"><div class="row"><a href="main.php?page=1" target="main"><?php print res_ALL; ?></a></div>
			</td>
		</tr><?php
		foreach ($_SESSION['categoryList'] as $category)
		{
		print "\t\t<tr>\n";
		print "\t\t\t<td bgcolor=\"#EFEFEF\"><div class=\"row\"><a href=\"main.php?page=2&field=category&filter=$category&offset=0\" target=\"main\">$category</a></div>\n";
		print "\t\t\t</td>\n";
		print "\t\t</tr>\n";
		} ?>
	</table>
</body>
<?php
}
?>