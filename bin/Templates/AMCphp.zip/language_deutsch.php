<?php

session_start();

/**
 * language_deutsch.php
 *
 * Vordefinierte Texte f�r deutsche �bersetzung.
 *
 * changes:
 *	- 07 Aug 03: initial version
 */

define ("res_SEARCH", "Suche");
define ("res_SEARCH_ACTORS_DIRECTORS_AND_TITLES", "Suchen in Schauspieler, Regisseur und Titel");

define ("res_LOADING", "wird geladen");
define ("res_CATEGORIES", "Kategorien");
define ("res_MOVIES", "Filme");
define ("res_ALL", "Alle");
define ("res_PAGE", "Seite");

define ("res_LIST", "Liste");
define ("res_SEARCH_RESULTS", "Suchergebnisse");
define ("res_DETAILS", "Details");
define ("res_STATISTICS", "Statistiken");
define ("res_OPTIONS", "Optionen");

define ("res_TITLE", "Titel");
define ("res_DIRECTOR", "Regisseur");
define ("res_COUNTRY", "Land");
define ("res_CATEGORY", "Kategorie");
define ("res_YEAR", "Jahr");
define ("res_LENGTH", "L�nge");
define ("res_RATING", "Wertung");

define ("res_DIRECTEDBY", "Regie");
define ("res_CAST", "Darsteller");
define ("res_DESCRIPTION", "Beschreibung");
define ("res_COMMENTS", "Kommentar");
define ("res_TECHNICALINFORMATION", "Technische Daten");
define ("res_LANGUAGE", "Sprache");
define ("res_SUBS", "Subs");
define ("res_ADDED", "Hinzugef�gt");
define ("res_STATUS", "Status");
define ("res_LENT", "Verliehen");
define ("res_NA", "/");

define ("res_COMPLETERUNTIME", "Komplette Laufzeit");
define ("res_AVERAGERUNTIME", "Durchschnittliche Laufzeit");
define ("res_PERCENTAGE", "Anteil");
define ("res_GENERATEACTORSREPORT", "Schauspieler Report generieren");
define ("res_GENERATEDIRECTORSREPORT", "Regisseur Report generieren");
define ("res_GENERATEHISTORYREPORT", "Historie Report generieren");
define ("res_ACTORSINLIST", "Schauspieler im Katalog");
define ("res_DIRECTORSINLIST", "Regisseure im Katalog");
define ("res_YEARSINLIST", "Jahre im Katalog");

define ("res_ROWSPERPAGE", "Zeilen pro Seite");
define ("res_UPDATE", "Update");
define ("res_MULTIPLEGENREACTIVE","Unterst�tzung mehrerer Genre aktiviert");

define ("res_NOSEARCHRESULTS", "Es wurden keine Suchergebnisse gefunden.");
define ("res_RESULTSFOUND", "Suchergebnisse gefunden.");
define ("res_NOMOVIESELECTED", "Bitte zuerst einen Film aus der Liste ausw�hlen.");
define ("res_CLICKTOCHANGESORT", "Klicken um Sortierung zu �ndern");
?>