<?php

session_start();

/**
 * language_slovenian.php
 *
 * predefinded strings for slovenian translation.
 *
 * changes:
 *	- 07 Aug 03: initial version
 */

define ("res_SEARCH", "i��i");
define ("res_SEARCH_ACTORS_DIRECTORS_AND_TITLES", "I��i igralce, re�iserje in naslove");

define ("res_LOADING", "se nalaga");
define ("res_CATEGORIES", "kategorije");
define ("res_MOVIES", "filmi");
define ("res_ALL", "vse");
define ("res_PAGE", "stran");

define ("res_LIST", "seznam");
define ("res_SEARCH_RESULTS", "poizvedi");
define ("res_DETAILS", "podrobnosti");
define ("res_STATISTICS", "statistika");
define ("res_OPTIONS", "mo�nosti");

define ("res_TITLE", "Naslov");
define ("res_DIRECTOR", "Re�iser");
define ("res_COUNTRY", "Dr�ava");
define ("res_CATEGORY", "Kategorija");
define ("res_YEAR", "Leto");
define ("res_LENGTH", "Dol�ina");
define ("res_RATING", "Ocena");

define ("res_DIRECTEDBY", "Re�iser");
define ("res_CAST", "Zasedba");
define ("res_COMMENTS", "Komentar");
define ("res_DESCRIPTION", "Opis");
define ("res_TECHNICALINFORMATION", "Tehni�ne Informacije");
define ("res_LANGUAGE", "Jezik");
define ("res_SUBS", "podnapisi");
define ("res_ADDED", "dodano");
define ("res_STATUS", "polo�aj");
define ("res_LENT", "posojeno");
define ("res_NA", "n/a");

define ("res_COMPLETERUNTIME", "celotni igralni �as");
define ("res_AVERAGERUNTIME", "povpe�ni igralni �as");
define ("res_PERCENTAGE", "odstotek");
define ("res_GENERATEACTORSREPORT", "ustvari seznam igralcev");
define ("res_GENERATEDIRECTORSREPORT", "ustvari seznam re�iserjev");
define ("res_GENERATEHISTORYREPORT", "generate history report");
define ("res_ACTORSINLIST", "igralci na seznamu");
define ("res_DIRECTORSINLIST", "re�iserji na seznamu");
define ("res_YEARSINLIST", "years in the list");

define ("res_ROWSPERPAGE", "Filmov na stran");
define ("res_UPDATE", "Osve�i");
define ("res_MULTIPLEGENREACTIVE","Podpora za ve� zvrsti, aktivna");

define ("res_NOSEARCHRESULTS", "Ni najdenih rezultatov.");
define ("res_RESULTSFOUND", "Najdeni rezultati.");
define ("res_NOMOVIESELECTED", "Izberite film s seznama.");
define ("res_CLICKTOCHANGESORT", "Klikni za razvrstitev");
?>
