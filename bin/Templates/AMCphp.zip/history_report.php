<?php

/**
 * history_report.php
 *
 * creates an html page with the history report
 *
 * changes:
 *	- 20 Feb 04: initial version
 */

	session_start();

	include('language_'.$_SESSION['currentLanguage'].'.php');

	print "<html><head>";
	print "<link rel=\"stylesheet\" type=\"text/css\" href=\"css/styles.css\"></head><body bgcolor=\"#FFFFFF\">";
	
	$yeararray = array();
	foreach($_SESSION['movieList'] as $arr)
	{
		$yeararray[$arr["movieYear"]] = $yeararray[$arr["movieYear"]]."<br>".$arr["movieOriginalTitle"];

	}
	print count($yeararray)." ".res_YEARSINLIST."<br>";
	ksort($yeararray);
	for($x=0;$x<sizeof($yeararray);$x++)
	{
		print "<br><b>".key($yeararray)."</b>".current($yeararray)."<br>";
		next($yeararray);
	}
	
	print "\n</body>\n</html>";
?>