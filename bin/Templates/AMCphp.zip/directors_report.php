<?php

/**
 * directors_report.php
 *
 * creates an html page with the directors report
 *
 * changes:
 *	- 28 Oct 03: initial version
 */

	session_start();

	include('language_'.$_SESSION['currentLanguage'].'.php');

	print "<html><head>";
	print "<link rel=\"stylesheet\" type=\"text/css\" href=\"css/styles.css\"></head><body bgcolor=\"#FFFFFF\">";
	
	$directorarray = array();
	foreach($_SESSION['movieList'] as $arr)
	{
		$temparray = explode(",",$arr["movieDirector"]);
		for($x=0;$x<count($temparray);$x++)
		{
			if($temparray[$x]!='')
			{
				$directorarray[trim($temparray[$x])] = $directorarray[$temparray[$x]]."<br>".$arr["movieOriginalTitle"]."...(".$arr["movieYear"].")";
			}
		}
	}
	print count($directorarray)." ".res_DIRECTORSINLIST."<br>";
	ksort($directorarray);
	for($x=0;$x<sizeof($directorarray);$x++)
	{
		print "<br><b>".key($directorarray)."</b>".current($directorarray)."<br>";
		next($directorarray);
	}
	
	print "\n</body>\n</html>";
?>