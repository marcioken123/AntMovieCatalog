<?php

session_start();

/**
 * language_spanish.php
 *
 * secuencias predefinidas para la traduci�n espa�ola
 *
 * changes:
 *	- 07 Aug 03: initial version
 */

define ("res_SEARCH", "buscar");
define ("res_SEARCH_ACTORS_DIRECTORS_AND_TITLES", "Buscar por actores, directores o t�tulo");

define ("res_LOADING", "cargando");
define ("res_CATEGORIES", "categor�as");
define ("res_MOVIES", "Pel�culas");
define ("res_ALL", "todas");
define ("res_PAGE", "p�gina");

define ("res_LIST", "lista");
define ("res_SEARCH_RESULTS", "resultados");
define ("res_DETAILS", "detalles");
define ("res_STATISTICS", "estadist�cas");
define ("res_OPTIONS", "opciones");

define ("res_TITLE", "T�tulo");
define ("res_DIRECTOR", "Director");
define ("res_COUNTRY", "Pa�s");
define ("res_CATEGORY", "Categor�a");
define ("res_YEAR", "A�o");
define ("res_LENGTH", "Duraci�n");
define ("res_RATING", "Calificaci�n");

define ("res_DIRECTEDBY", "Dirigida por");
define ("res_CAST", "Reparto");
define ("res_COMMENTS", "Comentarios");
define ("res_DESCRIPTION", "Descripci�n");
define ("res_TECHNICALINFORMATION", "Informaci�n T�cnica");
define ("res_LANGUAGE", "Lenguaje");
define ("res_SUBS", "subs");
define ("res_ADDED", "agregada");
define ("res_STATUS", "estado");
define ("res_LENT", "duraci�n");
define ("res_NA", "n/a");

define ("res_COMPLETERUNTIME", "tiempo pasado completo");
define ("res_AVERAGERUNTIME", "tiempo pasado medio");
define ("res_PERCENTAGE", "porcentaje");
define ("res_GENERATEACTORSREPORT", "generar reporte de actores");
define ("res_GENERATEDIRECTORSREPORT", "generate directors report");
define ("res_GENERATEHISTORYREPORT", "generate history report");
define ("res_ACTORSINLIST", "actores en la lista");
define ("res_DIRECTORSINLIST", "directors in the list");
define ("res_YEARSINLIST", "years in the list");

define ("res_ROWSPERPAGE", "Filas por p�gina");
define ("res_UPDATE", "Actualizar");
define ("res_MULTIPLEGENREACTIVE","soporte para m�ltiple generos activos");

define ("res_NOSEARCHRESULTS", "No hubo resultados para su b�squeda");
define ("res_RESULTSFOUND", "resultado(s) para la b�squeda");
define ("res_NOMOVIESELECTED", "Por favor seleccione una pel�cula de la lista primero.");
define ("res_CLICKTOCHANGESORT", "Click para cambiar clase");
?>