/**
 *
 * AMCphp - a php based template for Ant Movie Catalog
 * written by Ormus (2003 - 2004)
 * http://amc.loben.net
 *
 */

// Version: 
1.0 (24 Feb 2004)

// Requirements:
* Ant Movie Catalog @ http://www.antp.be/software/moviecatalog
  (tested version: 3.4.1, 3.4.2)

* PHP version 4 @ http://www.php.net
  (tested version: 4.2.2; sessions have to be activated; logging set to only errors)

* a PHP supporting webserver
  (tested: Apache 1.3.26, 1.3.27)

* a browser of choice, Internet Explorer recommended
  (tested on: IE 6.0; Netscape 7, Opera 7)

// Installation:
Extract the .zip file with it's directory structure.

Now open Ant Movie Catalog, open your database and select 
'File->Save As'. Save your catalog in xml format. Open parser.php
in a text editor and change the line:
$xmlSource="MovieCatalog.xml";
to your xml's filename/path.

More settings can be found in settings.php. Those settings include multiple-genre 
support and various additional configuration issues.

Copy your pictures directory, they have to stay at the same relative
path to the xml save.

Now put everything on your webserver and you should be ready to go.
Point the browsers to the index.html file.

// Known problems:
* contact me, if you encounter any other problems

// Contact:
email: Ormus7577@go.com
web: http://amc.loben.net

// Support:
support is provided via the AMC forum thread: http://forum.antp.be/phpbb2/viewtopic.php?t=813

// History:
24 Feb 04 :	version 1.0
		new things	* history report added
				* pictures with special characters are now displayed
04 Dec 03 :	version 0.9b6
		new things:	* bugs fixed (content linking, 0-9 list filter)
				* french translation added
10 Nov 03 :	version 0.9b5
		new things:	* a bug in actors report was fixed
				* Content linking option added
				* slovenian translation added

28 Oct 03 :	version 0.9b4
		new things:	* directors report added
				* subtitles field added
				* both titles shown in details (if both are set)

23 Oct 03 :	version 0.9b3
		new things:	* more statistics
				* actors report added
				* multiple genre support added
				* more fields from AMC are displayed in detail page (description etc.)

29 Aug 03 : 	version 0.9b2
		new things:	* first major statistic added
				* language can be switched during runtime
				* borrow status displayed in details
				* setting to use either original or translated movie title in lists added
				* '0-9' filter added

12 Aug 03 : 	initial version 0.9b