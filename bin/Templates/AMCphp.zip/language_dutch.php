<?php

session_start();

/**
 * language_dutch.php
 *
 * predefinded strings for translation.
 * (english is default language)
 *
 * changes:
 *	- 07 Aug 03: initial version
 */

define ("res_SEARCH", "Zoeken");
define ("res_SEARCH_ACTORS_DIRECTORS_AND_TITLES", "Zoek acteurs, regisseur of titel");

define ("res_LOADING", "loading");
define ("res_CATEGORIES", "Categori�n");
define ("res_MOVIES", "Films");
define ("res_ALL", "allemaal");
define ("res_PAGE", "pagina");

define ("res_LIST", "lijst");
define ("res_SEARCH_RESULTS", "zoekresultaat");
define ("res_DETAILS", "details");
define ("res_STATISTICS", "statistieken");
define ("res_OPTIONS", "opties");

define ("res_TITLE", "Titel");
define ("res_DIRECTOR", "Director");
define ("res_COUNTRY", "Land");
define ("res_CATEGORY", "Categorie");
define ("res_YEAR", "Jaar");
define ("res_LENGTH", "Lengte");
define ("res_RATING", "Beoordeling");

define ("res_DIRECTEDBY", "Regisseur");
define ("res_CAST", "Acteurs");
define ("res_DESCRIPTION", "Description");
define ("res_COMMENTS", "Commentaar");
define ("res_TECHNICALINFORMATION", "Technische info");
define ("res_LANGUAGE", "Taal");
define ("res_SUBS", "subs");
define ("res_ADDED", "Toegevoegd");
define ("res_STATUS", "status");
define ("res_LENT", "lent");
define ("res_NA", "n/a");

define ("res_COMPLETERUNTIME", "Totale duur");
define ("res_AVERAGERUNTIME", "Gemiddelde duur");
define ("res_PERCENTAGE", "percentage");
define ("res_GENERATEACTORSREPORT", "generate actors report");
define ("res_GENERATEDIRECTORSREPORT", "generate directors report");
define ("res_GENERATEHISTORYREPORT", "generate history report");
define ("res_ACTORSINLIST", "actors in the list");
define ("res_DIRECTORSINLIST", "directors in the list");
define ("res_YEARSINLIST", "years in the list");

define ("res_ROWSPERPAGE", "Aantal rijen per pagina");
define ("res_UPDATE", "Aanpassen");
define ("res_MULTIPLEGENREACTIVE","multiple genre support active");

define ("res_NOSEARCHRESULTS", "Geen resultaten gevonden");
define ("res_RESULTSFOUND", "Resultaten gevonden");
define ("res_NOMOVIESELECTED", "Selecteer eerst een film uit de lijst.");
define ("res_CLICKTOCHANGESORT", "Click to change sort");
?>