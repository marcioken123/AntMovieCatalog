<?php

session_start();

/**
 * language_english.php
 *
 * predefinded strings for english translation.
 *
 * changes:
 *	- 07 Aug 03: initial version
 */

define ("res_SEARCH", "search");
define ("res_SEARCH_ACTORS_DIRECTORS_AND_TITLES", "Search actors, directors and titles");

define ("res_LOADING", "loading");
define ("res_CATEGORIES", "categories");
define ("res_MOVIES", "Movies");
define ("res_ALL", "all");
define ("res_PAGE", "page");

define ("res_LIST", "list");
define ("res_SEARCH_RESULTS", "search results");
define ("res_DETAILS", "details");
define ("res_STATISTICS", "statistics");
define ("res_OPTIONS", "options");

define ("res_TITLE", "Title");
define ("res_DIRECTOR", "Director");
define ("res_COUNTRY", "Country");
define ("res_CATEGORY", "Category");
define ("res_YEAR", "Year");
define ("res_LENGTH", "Length");
define ("res_RATING", "Rating");

define ("res_DIRECTEDBY", "Directed by");
define ("res_CAST", "Cast");
define ("res_COMMENTS", "Comments");
define ("res_DESCRIPTION", "Description");
define ("res_TECHNICALINFORMATION", "Technical Information");
define ("res_LANGUAGE", "Language");
define ("res_SUBS", "subs");
define ("res_ADDED", "added");
define ("res_STATUS", "status");
define ("res_LENT", "lent");
define ("res_NA", "n/a");

define ("res_COMPLETERUNTIME", "complete runtime");
define ("res_AVERAGERUNTIME", "average runtime");
define ("res_PERCENTAGE", "percentage");
define ("res_GENERATEACTORSREPORT", "generate actors report");
define ("res_GENERATEDIRECTORSREPORT", "generate directors report");
define ("res_GENERATEHISTORYREPORT", "generate history report");
define ("res_ACTORSINLIST", "actors in the list");
define ("res_DIRECTORSINLIST", "directors in the list");
define ("res_YEARSINLIST", "years in the list");

define ("res_ROWSPERPAGE", "Rows per page");
define ("res_UPDATE", "Update");
define ("res_MULTIPLEGENREACTIVE","multiple genre support active");

define ("res_NOSEARCHRESULTS", "No search results found.");
define ("res_RESULTSFOUND", "search results found.");
define ("res_NOMOVIESELECTED", "Please select a movie from the list first.");
define ("res_CLICKTOCHANGESORT", "Click to change sort");
?>