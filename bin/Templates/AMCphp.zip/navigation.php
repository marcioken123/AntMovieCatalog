<?php

session_start();

/**
 * navigation.php
 *
 * displays the navigation frame
 *
 * changes:
 *	- 07 Aug 03: initial version
 */

include('settings.php');
include('language_'.$_SESSION['currentLanguage'].'.php');

?>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="css/styles.css">
</head>
<body bgcolor="#FFFFFF">
<?php
if (!isset($_SESSION['currentSubPage'])) 
{
    	print "\t<div class=\"normaltext\">";
	print resLOADING;
	print "...</div>\n";
	print "\t<meta http-equiv=\"refresh\" content=\"2; URL=navigation.php\">";
	print "</body>";
} else
{
	print "\t<table align=\"center\" border=\"1\" cellspacing=\"0\" cellpadding=\"2\">\n";
	print "\t\t<tr>\n\t\t\t<td align=\"center\" width=\"100\" ";
	if ($_SESSION['currentSubPage'] == 1) 
	{
    		print "bgcolor=\"#EFEFEF\"";
	}
	print "><a href=\"main.php?page=1\" target=\"main\">";
	print res_LIST;
	print "</a>\n\t\t\t</td>\n\t\t\t<td align=\"center\" width=\"100\" ";
	if ($_SESSION['currentSubPage'] == 2) 
	{
		print "bgcolor=\"#EFEFEF\"";
	}
	print "><a href=\"main.php?page=2\" target=\"main\">";
	print res_SEARCH_RESULTS;
	print "</a>\n\t\t\t</td>\n\t\t\t<td align=\"center\" width=\"100\" ";
	if ($_SESSION['currentSubPage'] == 3) 
	{
		print "bgcolor=\"#EFEFEF\"";
	}
	print "><a href=\"main.php?page=3\" target=\"main\">";
	print res_DETAILS;
	print "</a>\n\t\t\t</td>\n\t\t\t<td align=\"center\" width=\"100\" ";
	if ($_SESSION['currentSubPage'] == 4) 
	{
		print "bgcolor=\"#EFEFEF\"";
	}
	print "><a href=\"main.php?page=4&CatStats=vala\" target=\"main\">";
	print res_STATISTICS;
	print "</a>\n\t\t\t</td>\n\t\t\t<td align=\"center\" width=\"100\" ";
	if ($_SESSION['currentSubPage'] == 5) 
	{
		print "bgcolor=\"#EFEFEF\"";
	}
	print "><a href=\"main.php?page=5\" target=\"main\">";
	print res_OPTIONS;
	print "</a>\n\t\t\t</td>\n\t\t</tr>\n\t</table>";
?></body>
</html>
<?php
}
?>