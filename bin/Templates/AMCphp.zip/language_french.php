<?php

session_start();

/**
* language_fran�ais.php
*
* Textes pour la version fran�aise
*
* changes:
*  	- 22 Nov 03: French version
*       - 07 Aug 03: initial version
*/

define ("res_SEARCH", "Recherche");
define ("res_SEARCH_ACTORS_DIRECTORS_AND_TITLES", "Rechercher un film, un acteur, un r�alisateur...");

define ("res_LOADING", "Chargement");
define ("res_CATEGORIES", "Cat�gories ");
define ("res_MOVIES", "Films ");
define ("res_ALL", "Tout");
define ("res_PAGE", "Page");

define ("res_LIST", "Liste");
define ("res_SEARCH_RESULTS", "R�sultats...");
define ("res_DETAILS", "D�tails");
define ("res_STATISTICS", "Statistiques");
define ("res_OPTIONS", "Options");

define ("res_TITLE", "Titre");
define ("res_DIRECTOR", "R�alisateur");
define ("res_COUNTRY", "Pays");
define ("res_CATEGORY", "Cat�gorie");
define ("res_YEAR", "Ann�e");
define ("res_LENGTH", "Dur�e");
define ("res_RATING", "Note");

define ("res_DIRECTEDBY", "R�alis� par ");
define ("res_CAST", "Acteurs ");
define ("res_COMMENTS", "Commentaires ");
define ("res_DESCRIPTION", "Description ");
define ("res_TECHNICALINFORMATION", "Informations techniques ");
define ("res_LANGUAGE", "Langue ");
define ("res_SUBS", "sous-titre ");
define ("res_ADDED", "Ajout� ");
define ("res_STATUS", "Status ");
define ("res_LENT", "lent");
define ("res_NA", "-");

define ("res_COMPLETERUNTIME", "Dur�e totale");
define ("res_AVERAGERUNTIME", "Dur�e moyenne");
define ("res_PERCENTAGE", "Pourcentage");
define ("res_GENERATEACTORSREPORT", "Films par acteurs");
define ("res_GENERATEDIRECTORSREPORT", "Films par r�alisateur");
define ("res_GENERATEHISTORYREPORT", "generate history report");
define ("res_ACTORSINLIST", "Acteurs dans la liste");
define ("res_DIRECTORSINLIST", "R�alisateur dans la liste");
define ("res_YEARSINLIST", "years in the list");

define ("res_ROWSPERPAGE", "Lignes par page ");
define ("res_UPDATE", "Valider");
define ("res_MULTIPLEGENREACTIVE","multiple genre support active");

define ("res_NOSEARCHRESULTS", "Aucun r�sultat trouv�");
define ("res_RESULTSFOUND", "R�sultats trouv�s");
define ("res_NOMOVIESELECTED", "S�lectionner, tout d'abord, un film dans la liste");
define ("res_CLICKTOCHANGESORT", "Changer le tri");
?>