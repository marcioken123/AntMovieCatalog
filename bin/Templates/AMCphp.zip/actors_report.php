<?php

/**
 * actors_report.php
 *
 * creates an html page with the actors report
 *
 * changes:
 *	- 22 Oct 03: initial version
 *	- 23 Oct 03: imdb-style lists added
 */

	session_start();

	include('language_'.$_SESSION['currentLanguage'].'.php');

	print "<html><head>";
	print "<link rel=\"stylesheet\" type=\"text/css\" href=\"css/styles.css\"></head><body bgcolor=\"#FFFFFF\">";
	
	$actorarray = array();
	foreach($_SESSION['movieList'] as $arr)
	{
		if($_SESSION['ActorsSeparator'] == "imdb")
		{
			$temparray = explode("),",$arr["movieActors"]); 
			for($x=0;$x<count($temparray);$x++)
			{
				if($temparray[$x]!='')
				{
					if(strpos($temparray[$x], "(") != false)
					{
						$actorstring = substr($temparray[$x], 0, strpos($temparray[$x], "("));
					} else
					{
						$actorstring = $temparray[$x];
					}
					$actorarray[trim($actorstring)] = $actorarray[trim($actorstring)]."<br>".$arr["movieOriginalTitle"]."...(".$arr["movieYear"].")";
				}
			}
		} else
		{
			$temparray = explode($_SESSION['ActorsSeparator'],$arr["movieActors"]); 
			for($x=0;$x<count($temparray);$x++)
			{
				if($temparray[$x]!='')
				{
					$actorarray[trim($temparray[$x])] = $actorarray[trim($temparray[$x])]."<br>".$arr["movieOriginalTitle"]."...(".$arr["movieYear"].")";
				}
			}
		}
	}
	print count($actorarray)." ".res_ACTORSINLIST."<br>";
	ksort($actorarray);
	for($x=0;$x<sizeof($actorarray);$x++)
	{
		print "<br><b>".key($actorarray)."</b>".current($actorarray)."<br>";
		next($actorarray);
	}
	
	print "\n</body>\n</html>";
?>