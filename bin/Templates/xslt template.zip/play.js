var cdDriveLetter = 'F';
var fileSufixes = new Array("avi", "mpg", "divx");
/* 
 * Searches the specified cd drive for the first avi file.
 * Launches the specified player with the avi file as argument.
 * Hopefully the player will start the movie.
 */ 
function play() {
	var wScript = new ActiveXObject("Wscript.Shell");
	var fso = new ActiveXObject("Scripting.FileSystemObject");
 	var folder = fso.GetFolder(cdDriveLetter + ":");
 	var fc = new Enumerator(folder.files);
	var file = null;
	var fileName = "";
 		outer: for (; !fc.atEnd(); fc.moveNext()){
		fileName = fc.item().Name.toLowerCase();
		for (var i = 0; i < fileSufixes.length; i++) {
			if ( fileName.indexOf(fileSufixes[i].toLowerCase()) == fileName.length - fileSufixes[i].length ) {
				file = '"' + fc.item().Path + '"';
				break outer;
			}
		}
	}
	if (file != null) {
		wScript.Run(file);
	} else {
		alert("Could not find any movie file on  " + cdDriveLetter + "!");
	}
}