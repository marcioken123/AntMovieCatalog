-----------------------------------------
|					|
|	Template by Willspo		|
|	wille@tegenaria.com		|
|					|
-----------------------------------------

Install
-----------------------------------------
1.Save the file data/movies.xml as something.html and place it in the same directory as your Movie Catalog templates. 
2.Start Movie Catalog 
3.Export as html (full with images) 
4.Choose something.html as your template and save the target as movies.xml in your source directory/data 
5.Run

Run
-----------------------------------------
Run index.html 		if you want to show your movie info in Internet Explorer
Run index.hta 		if you want to be able to launch movies from your moive list
Run index_tv.hta	if you want to view the list on a tv (with 800x600 res)

!! For the play function to work you have to modify the first line in play.js (open in notepad)
var cdDriveLetter = 'e'; (change e to your cd-drive letter)


