<?
global $valeur;
include("conf/config.dat");
include "lang/lang.".$lang.".inc";

if($P_membre=="on") {

if(isset($_POST["Ajout"])) {

	if ($_POST["pseu"]!="" && $_POST["passe"]!="") {
		$fichiers="data/users/" . $_POST["pseu"] . ".inf.dat";
		if(!file_exists($fichiers)) {
			$pass1=md5($_POST["passe"]);
			$rang=0;
			$value=$pass1 . ";" . $rang . "\n";
			$fd = fopen ($fichiers,"a+");
			fputs($fd,$value);
			$ligne=$Cat_defaut . ";" . $Ch_cat_defaut . "\n";
			fputs($fd,$ligne);				
			fclose ($fd);
		}
	
	}

header("Location: index.php");

} // fin isset add

?>
<HTML>
<HEAD>
<TITLE> <?echo $LANG["Devenir_membre"] ?> </TITLE>
<LINK rel="stylesheet" type="text/css" href="conf/style.css">
</HEAD>
<BODY>
<form action="membre.php" method="post"> 
<TABLE class=outer cellSpacing=1 width="100%">
<TBODY>
<TR>
<TH colSpan=2><?echo $LANG["Devenir_membre"] ?></TH></TR>
<TR valign=top align=left>
<TD class=head><?echo $LANG["M_pseudo"] ?></TD>
<TD class=even><input type="text" name="pseu" size="20" maxlength="30"></TD>

<TR valign=top align=left>
<TD class=head><?echo $LANG["M_password"] ?></TD>
<TD class=even><input type="password" name="passe" size="15" maxlength="20"></TD>
</TR>

<TR valign=top align=left>
<TD class="head" colspan="2"><CENTER><INPUT type="submit" name="Ajout" value="<?echo $LANG["Bouton_soumettre"] ?>"></CENTER></TD>
</TR>
</TBODY>
</TABLE>
<BR><BR>
</FORM>
</BODY>
</HTML>

<?
} // fin du if = membre
?>