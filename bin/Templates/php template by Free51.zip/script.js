function mouseOverTR(trObj) {
	trObj.className = "movieListSelected";
}    

function mouseOutTR(trObj) {
	trObj.className = "movieList";
}


function openNewWindow(URLtoOpen,windowName,width,height) 
{ 
windowFeatures ="menubar=no,scrollbars=no,location=no,favorites=no,resizable=no,status=no,toolbar=no,directories=no"; 
var test = "'"; 
winLeft = (screen.width-width)/2; 
winTop = (screen.height-(height+110))/2; 
myWin= open(URLtoOpen,windowName,"width=" + width +",height=" + height + ",left=" + winLeft + ",top=" + winTop + test + windowFeatures + test); 
return(false);
} 