<?
session_start();
foreach( $_ENV as $e => $f )
 {
 $$e = $f;
 }
 foreach( $_SERVER as $e => $f )
 {
 $$e = $f;
 }
 foreach( $_REQUEST as $e => $f )
 {
 $$e = $f;
 }
 foreach( $_SESSION as $e => $f )
 {
 $$e = $f;
 }
 


global $valeur,$Pass;
session_unregister("Pass");
		session_unregister("Admin");
		// On supprime ttes les variables de la session 
		session_unset(); 

		// On d�truit totalement la session 
		session_destroy();

include("config.dat");
include "../lang/lang.".$lang.".inc";
if(isset($Login)) {
	$fichiers="../data/users/".$Login .".inf.dat";
	if( file_exists($fichiers)) {
	$file = fopen($fichiers, "r");
	$line = fgetcsv($file,1000, ";");
	$buffer = fgetcsv($file,1000, ";");
	fclose ($file);
	$pass1=md5($Passe);
	
	if($line[0] != $pass1){
		header ("Location: mlogin.php");
	}
	else
	{
		//session_start();
		session_register("Pass");
		session_register("Ch_catalog");
		session_register("Catalogue");
		session_register("Admin");
		$_SESSION['Pass']=$Login;
		$Pass=$Login;
		$_SESSION['Catalogue']=$buffer[1].$buffer[0];
		$Catalogue=$buffer[1].$buffer[0];
		$_SESSION['Ch_catalog']=$buffer[1];
		$Ch_catalog=$buffer[1];
		if($line[1]=="1"){
			$_SESSION['Admin']=1;
		}
		else
		{
			$_SESSION['Admin']=0;
		}
	
	header ("Location: index.php");
	exit;
	}
}
header ("Location: mlogin.php");
}
else
{

?>
<html>

<head>

<title><?echo $LANG["Title_admin"] ?></title>
<LINK rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
        <table border='0' width='100%' cellspacing='0' cellpadding='0'>
		<tr>
        <td bgcolor='#2F5376'><img src='images/templatelogo.jpg' alt='Template Site' /></td>
        <td align='right' bgcolor='#2F5376' colspan='2'><img src='images/version.jpg' alt='' /></td>
		</tr>
		</TABLE>
<meta name="description" content="">
<meta name="keywords" content="">
<style type="text/css">
<!--

.boutons {
	BACKGROUND-COLOR: #c6c6c6; BORDER-BOTTOM: #000000 1px solid; BORDER-LEFT: #FFFFFF 1px solid; BORDER-RIGHT: #000000 1px solid; BORDER-TOP: #c3c3c3 1px solid; COLOR: #ffffff;
}
-->
</style>
</head>



      <form method="POST" action="mlogin.php" name="ok"><div align="center">
	  
	   <table width="400" border="0" cellpadding="0" cellspacing="0" height="235" >
          <tr> 
            <td> 
              <table  width="395" border="0" cellpadding="0" cellspacing="0">
                <tr width="400"> 
                  <td width="340" align="right"><font color="#ff0000"><b>
				  
				  </b></font>
				  </td>
               
                </tr>
                <tr width="400"> 
                  <td width="240" align="right" height="37"><b><?echo $LANG["B_Login"] ?></b></td>
                  <td width="10" height="37"></td>
                  <td width="140" align="right" height="37"> 
                    <input type="text" name="Login">
                  </td>
                  <td width="10" height="37"></td>
                </tr>
                <tr width="400"> 
                  <td width="240" align="right" height="42"><b><?echo $LANG["B_Password"] ?></b></td>
                  <td width="10" height="42"></td>
                  <td width="140" align="right" height="42"> 
                    <input type="password" name="Passe">
                  </td>
                  <td width="10" height="42"></td>
                </tr>
                <tr width="400"> 
                  <td width="240" height="37">&nbsp;</td>
                  <td width="10" height="37"></td>
                  <td width="140" align="right" valign="Botton" height="37">
                    
					<INPUT class='boutons' TYPE=SUBMIT NAME=SUBMIT VALUE="<?echo $LANG["Bouton_soumettre"] ?>">
                  </td>
                  <td width="10" height="37"></td>
                </tr>
                <tr width="400"> 
                  <td width="240"> 
                    <div align="right"></div>
                  </td>
                  <td width="10"></td>
                  <td width="140" align="right" valign="Botton"> 
                    <div align="left"><font size="2"> </font></div>
                  </td>
                  <td width="10"></td>
                </tr>
                
                
              </table>
  </form>


   </TD>
  </TR>
 

</TABLE>


</body>
</html>
<?
}
?>