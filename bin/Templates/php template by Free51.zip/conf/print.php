<?session_start();
////////////////////////////////////////////////////////////////
//  Fichier : print.php
//  Version Template-PHP : 3.0
//  Release : 101
//  Date : 17/02/04
//  De : Free51  / Free51@passions-numerique.net
//
////////////////////////////////////////////////////////////////
foreach( $_ENV as $e => $f )
 {
 $$e = $f;
 }
 foreach( $_SERVER as $e => $f )
 {
 $$e = $f;
 }
 foreach( $_REQUEST as $e => $f )
 {
 $$e = $f;
 }
 foreach( $_SESSION as $e => $f )
 {
 $$e = $f;
 }
////////////////////////////////PRE-DECLARATION /////////////////////////////////////////////
global $Name,$Type,$valeur;
////////////////////////////////////////////////////////////////////////////////////////////
ini_set('session.use_trans_sid', false);
ini_set('session.use_only_cookies', false); 
ini_set('session.bug_compat_warn' ,false);


header("Last-Modified: ".gmdate("D, d M Y H:i:s")."GMT"); // page toujours modifi�e
header("Cache-Control: no-cache, must revalidate"); // Pas de cache serveur
header ("Pragma: no-cache"); // Pas de cache navigateur
if(session_is_registered('Pass') and $Admin=="1") {
include("config.dat");
include "../lang/lang.".$lang.".inc";
$Name=ereg_replace(" ","",$Name); //nettoyage de la variable


if($Type==1) {
	$fd = fopen ("../data/panier/demande.dat", "r");
}
if($Type==2) {
	$fd = fopen ("../data/panier/encours.dat", "r");
}
if($Type==3) {
	$fd = fopen ("../data/panier/precedent.dat", "r");
}
echo" 
<html>
<head>
<link rel=\"stylesheet\" type=\"text/css\" href=\"../style.css\" />
<script language=\"javaScript\" src=\"../script.js\"></script>
</head>
<a class=\"button\" href=\"javascript:window.print()\">".$LANG['V_imprimer']."</a>
<a class=\"button\" href=\"javascript:window.close()\">".$LANG['V_Fermer']."</a>
<BR><BR>
<table border=1 width=100%>";
echo"<tr>
		<td width=40><div align=center><b>N�</b></div></td>
		<td width=65%><div align=center><b>Titre</b></div></td>
		<td><div align=center><b>Nom</b></div></td>
	</tr>";
	
	
while (!feof ($fd)) {    
	$buffer =  fgetcsv ($fd, 2048, ";");
	
	if($buffer[2]==$Name) {
		

	echo"<tr>
		<td><div align=right>$buffer[0]</div></td>
		<td>$buffer[1]</td>
		<td><div align=center>$buffer[2]</div></td>
	</tr>";




	}
}
fclose($fd);

echo "</table>";


}//fin du if sessions
?>