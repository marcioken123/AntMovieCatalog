<?session_start();
foreach( $_ENV as $e => $f )
 {
 $$e = $f;
 }
 foreach( $_SERVER as $e => $f )
 {
 $$e = $f;
 }
 foreach( $_REQUEST as $e => $f )
 {
 $$e = $f;
 }
 foreach( $_SESSION as $e => $f )
 {
 $$e = $f;
 }
////////////////////////////////PRE-DECLARATION /////////////////////////////////////////////
global $S_panier,$val,$enr,$i,$valeur,$Pass,$Page,$pseudo,$dossier,$Version_hs,$Message_erreur,$DejaPris,$Nom_Cat,$Enr_Pseudo;
////////////////////////////////////////////////////////////////////////////////////////////
ini_set('session.use_trans_sid', false);
ini_set('session.use_only_cookies', false); 
ini_set('session.bug_compat_warn' ,false);


header("Last-Modified: ".gmdate("D, d M Y H:i:s")."GMT"); // page toujours modifi�e
header("Cache-Control: no-cache, must revalidate"); // Pas de cache serveur
header ("Pragma: no-cache"); // Pas de cache navigateur

if(isset($ko)) {
		session_unregister("Pass");
		session_unregister("Admin");
		// On supprime ttes les variables de la session 
		session_unset(); 

		// On d�truit totalement la session 
		session_destroy();
		
		
}



if(session_is_registered('Pass') and $Admin=="1") {
include("config.dat");
include "../lang/lang.".$lang.".inc";

?>

<html>


<head>



</script>
<title><?echo $LANG["Title_admin"] ?></title>
<LINK rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
        <table border='0' width='100%' cellspacing='0' cellpadding='0'>
		<tr>
        <td bgcolor='#2F5376'><img src='images/templatelogo.jpg' alt='Template Config' /></td>
        <td align='right' bgcolor='#2F5376' colspan='2'><img src='images/version.jpg' alt='' /><BR>
			<div align="right"><font color="#ffcc00"><b><?echo $Version ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b></font></div></td>
		</tr>
        <tr>
        <td align='left' colspan='3' class='bg5'>
        <table border='0' width='100%' cellspacing='0' cellpadding='0'>
        <tr>
          <td width='1%'><img src='images/hbar_left.gif' width='10' height='23'></td>
          <td width='20%' background='images/hbar_middle.gif' >&nbsp;<a href='../index.php'><font size="2"><b><?echo $LANG["Retour_cat"] ?></b></font></a></td>
          <td width='78%' background='images/hbar_middle.gif' align='right'><a href='index.php?ko='><font size="2"><b><?echo $LANG["L_deconnect"] ?></b></font></a>&nbsp</td>
          <td width='1%'><img src='images/hbar_right.gif' width='10' height='23'></td>
        </tr>
        </table>
        </td></tr>
        </table>

<table border="0" width="100%">
	<tr>
		<td width="150" bgcolor="#E6E6E6" align="middle"  valign="top"> <!-- Colonne menu -->
		<BR>
		<A HREF='index.php?Page=users'><img src="images/membre.jpg" border="0" width="50" height="41" alt=""><BR><font size="2"><b><?echo $LANG["Gestion_acces"] ?></b></font></A><BR><BR>
		<A HREF='index.php?Page=catalog'><img src="images/service.jpg" border="0" width="50" height="41" alt=""><BR><font size="2"><b><?echo $LANG["Gestion_cat"] ?></b></font></A><BR><BR>
		<A HREF='index.php?Page=pref'><img src="images/admin.jpg" border="0" width="50" height="41" alt=""><BR><font size="2"><b><?echo $LANG["Gestion_pref"] ?></b></font></A><BR><BR>
		<!--<A HREF='index.php?Page=fiche'><img src="images/admin.jpg" border="0" width="50" height="41" alt=""><BR><font size="2"><b><?echo $LANG["Gestion_Fiche"] ?></b></font></A><BR><BR>-->
		<? if ($S_panier=="on") { ?>
		<A HREF='index.php?Page=panier'><img src="images/panier.jpg" border="0" width="50" height="41" alt=""><BR><font size="2"><b><?echo $LANG["Gestion_panier"] ?></b></font></A><BR><BR>
		<? } ?>
		<A HREF='index.php?Page=maj'><img src="images/prefs.jpg" border="0" width="50" height="41" alt=""><BR><font size="2"><b><?echo $LANG["P_maj"] ?></b></font></A><BR><BR>
		
		
		
		</td> <!-- fin colonne menu -->
		<TD valign="top">
		
		
	
		<? if($Page!="") {
		$fichier="includes/".$Page .".inc";
		if(file_exists($fichier)){
		include ($fichier);
		}
		else
		{
		echo "<font color=\"#ff0000\">".$LANG["No_page"] ."</font>";
		}
		}
		?>
		
		
			
		
		
		</td><!-- fin page main -->
	</tr>
</table>
<table border='0' width='100%' cellspacing='0' cellpadding='0'>
        <tr>
          <td width='1%'><img src='images/hbar_left.gif' width='10' height='23'></td>
          <td width="98%" background="images/hbar_middle.gif" align="center">&nbsp;<font size="2"><b>Template-PHP  � 2001-2003</b></font></a></td>
          <td width='1%'><img src='images/hbar_right.gif' width='10' height='23'></td>

        </tr>
        </table>
	
		
		
		
<?php

?>
</body>
</html>
<? 
}
else
{
header ("Location: mlogin.php");
} // fin if session
?>