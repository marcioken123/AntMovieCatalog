<?session_start();
////////////////////////////////////////////////////////////////
//  Fichier : Com.php
//  Version Template-PHP : 3.X
//  Release : 100
//  Date : 07/04/04
//  De : Free51  / Free51@passions-numerique.net
//
////////////////////////////////////////////////////////////////


foreach( $_ENV as $e => $f )
 {
 $$e = $f;
 }
 foreach( $_SERVER as $e => $f )
 {
 $$e = $f;
 }
 foreach( $_REQUEST as $e => $f )
 {
 $$e = $f;
 }
foreach( $_SESSION as $e => $f )
 {
 $$e = $f;
 }

if(session_is_registered('Pass')) {
global $valeur,$Pass;
include("conf/config.dat");
include "lang/lang.".$lang.".inc";


$Rep= explode("/", $Ch_catalog);
$fichier=$Rep[2]."_".$fiche .".dat";
$chemin="data/commentaires/". $fichier;
if(!file_exists($chemin)) {
	$file=fopen($chemin,"a");
	fclose($file);
}


function cleaner ($text)
{
	$text=ereg_replace(";",",",$text);
	$text=ereg_replace("<"," ",$text);
	$text=ereg_replace(">"," ",$text);
	$text=ereg_replace("../"," ",$text);
	$text=ereg_replace("\n","<BR>",$text);
	$text=ereg_replace("\r","",$text);
	$text=trim($text);
	$text=stripslashes($text); 
	return $text;
}

if(isset($Ajout)) {
$date_calc=strftime("%d/%m/%Y %H:%M",time());
$file=fopen($chemin,"a");
$Commentaire= cleaner($Commentaire);
$ligne=$Pass. ";" . $date_calc . ";" . $Note . "\n";
fputs($file,$ligne);
$ligne=$Commentaire . "\n";	
fputs($file,$ligne);
fclose ($file);


}
$Tableau_C = array();
$file=fopen($chemin,"r"); 	
	while (!feof ($file)) {
		$buffer =  fgetcsv ($file, 2048, ";");	
		$buffer1 =  fgetcsv ($file, 2048, ";");
		if($buffer[0]!="") { 
			array_push ($Tableau_C, array("User"=>$buffer[0],"Date"=>$buffer[1],"Note"=>$buffer[2],"Commentaire"=>$buffer1[0]));
		}				
		
	}
fclose ($file);
reset($Tableau_C);
$Nb_com=count($Tableau_C);




?>
<html>
<head>
<title>--  <? echo $LANG["Titre_commentaire"]?> --</title>
<link rel="stylesheet" type="text/css" href="conf/style.css" />


</head>

<body >
<div align="center">
<table border="0" width="750" bgcolor="#9999CC">
	<tr bgcolor="#999999">
		<td><?echo $LANG["ilya"]. " ". $Nb_com . " " . $LANG["commentaires"]  ?></td>
	</tr>
	<tr>
		<td>
		<?
		while(list(,$val) = each($Tableau_C)){
		if($Pass==$val['User']){
			$No_Ajout="yes";
		}
		
		?>
		<table cellspacing="0" width="100%">
		<tr>
			<TD class=head width="20%" ><?echo $LANG["De"] ?><b><?echo $val['User'] ?></b></TD>
			<TD class=head><?echo $LANG["Le"] .$val['Date'] ?> </TD>
			<TD class=head> <?echo $LANG["Note"] ?><b><?echo $val['Note'] ?></b> </TD>
		</tr>
		<TR>
			<TD colspan="3" class=even> <?echo $val['Commentaire'] ?> </TD>
		
		</TR>
		</table>
		<BR>
		<?
		}
		?>
		
		</td>
	</tr>
</table>
</div>

<? if(!isset($Ajout) && !isset($No_Ajout)) { 
	
?>
<form action="com.php?fiche=<?echo $fiche ?>" method="post"> 
<div align="center">
<table border="0" width="350">
	<tr >
		<td class="head"><?echo $LANG["Ajout_commentaire"] ?></td>
	</tr>
	
	
	<tr>
		<?
		if($pword=="on") {
		?>
		<td class="even">Nom : <b><?echo $Pass ?></b>
		
		<div align="right"><?echo $LANG["Note"] ?><select name="Note">
                     	<option value="1"> 1</option>
                     	<option value="2"> 2</option>
                     	<option value="3"> 3</option>
                     	<option value="4"> 4</option>
                     	<option value="5" selected> 5</option>
                     	<option value="6"> 6</option>
                     	<option value="7"> 7</option>
                     	<option value="8"> 8</option>
                     	<option value="9"> 9</option>
                     	<option value="10"> 10</option>
                     </select>
                     </div></td>
		<?
		}
		else
		{
		?>
		<td>Nom :<b><input type="text" name="Pseudo" size="15" maxlength="15">
             </b>
		</td>
		<?
		}
		?>
	</tr>
	<tr>
		<td><?echo $LANG["Titre_commentaire"] ?> :<BR>
		<textarea name="Commentaire" cols="40" rows="5"> </textarea>
  
 
  
		
		
		</td>
	</tr>
	
	<tr>
		<td><INPUT type="submit" name="Ajout" value="<?echo $LANG["Bouton_Accepter"] ?>"></td>
	</tr>
	
</table></div>
</form>


<?
}


?>
<BR><BR>
<div align="center"><a class="button" href="javascript:window.close()"><?echo $LANG["V_Fermer"] ?></a></div>

</body>
</html>
<?
} // fin du if session