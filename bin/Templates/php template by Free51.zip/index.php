<?session_start();
////////////////////////////////////////////////////////////////
//  Fichier : Index.php
//  Version Template-PHP : 3.0
//  Release : 110
//  Date : 27/02/04
//  De : Free51  / Free51@passions-numerique.net
//
////////////////////////////////////////////////////////////////


foreach( $_ENV as $e => $f )
 {
 $$e = $f;
 }
 foreach( $_SERVER as $e => $f )
 {
 $$e = $f;
 }
 foreach( $_REQUEST as $e => $f )
 {
 $$e = $f;
 }
 foreach( $_SESSION as $e => $f )
 {
 $$e = $f;
 }

////////////////////////////////PRE-DECLARATION /////////////////////////////////////////////
global $cat,$changecat,$Pass,$page,$valeur,$M_Nentier,$trie,$guide,$recherche,$Acteurs,$info,$Add,$Del,$Emprunteur,$Demande,$DejaPris,$Autre_emp ;
$Acteurs=array();
include("conf/config.dat");
include "lang/lang.".$lang.".inc";
////////////////////////////////////////////////////////////////////////////////////////////


if (isset($ko)) {
		

		session_unregister("Pass");
		session_unregister("Admin");
		session_unregister("Catalogue");
		session_unregister("Ch_catalog");
		session_unregister("Message");
		// On supprime ttes les variables de la session 
		session_unset(); 

		// On d�truit totalement la session 
		session_destroy();
	}

	
if($pword=="on") {
if (isset($ok)) {
		
		$fichiers="data/users/". $Login .".inf.dat";
		if( file_exists($fichiers)) {
			$file = fopen($fichiers, "r");
			$line = fgetcsv($file,2048, ";");
			fclose ($file);
			$pass1=md5($Passe);
			
			$fd = fopen ("data/users/$Login.inf.dat", "r");
		  	
				 $i=0;
				 while (!feof ($fd)) {    
					$i++;
					$buffer =  fgetcsv ($fd, 2048, ";");
					if($i==2) {
						$P_cat=$buffer[1].$buffer[0];
						$P_chcat=$buffer[1];
					}
					
				}
			fclose($fd);
			
			if($line[0] != $pass1 or $i<2){
				header ("Location: index.php");
			}
			else
			{
				//session_start();
				session_register("Pass");
				session_register("Admin");
				session_register("Ch_catalog");
				session_register("Catalogue");
				session_register("Message");
				$_SESSION['Message']=0;
				$_SESSION['Pass']=$Login;
				$Pass=$Login;
				$_SESSION['Catalogue']=$P_cat;
				$Catalogue=$P_cat;
				$_SESSION['Ch_catalog']=$P_chcat;
				$Ch_catalog=$P_chcat;
				if($line[1]=="1"){
					$_SESSION['Admin']=1;
					$Admin=1;
				}
				else
				{
					$_SESSION['Admin']=0;
					$Admin=0;
				}		
			
			}
		}
}
}
else
{
session_register("Pass");
session_register("Ch_catalog");
session_register("Catalogue");
session_register("Admin");
$_SESSION['Catalogue']=$Ch_cat_defaut.$Cat_defaut;
$Catalogue=$Ch_cat_defaut.$Cat_defaut;
$_SESSION['Ch_catalog']=$Ch_cat_defaut;
$Ch_catalog=$Ch_cat_defaut;
$_SESSION['Admin']=0;
$Admin=0;
}


if($changecat!=""){

$fd = fopen ("data/users/$Pass.inf.dat", "r");
		  	
	$i=0;
		while (!feof ($fd)) {    
			$i++;
			$compte =  fgetcsv ($fd, 2048, ";");
			if($i==$changecat) {
				$_SESSION['Catalogue']=$compte[1].$compte[0];
				$Catalogue=$compte[1].$compte[0];
				$_SESSION['Ch_catalog']=$compte[1];
				$Ch_catalog=$compte[1];	
			}		
		}
fclose($fd);



} // fin du if changecat







if(!session_is_registered('Pass')) {



	
	
	
//////////////////////////////////////// DEBUT HTML ///////////////////////////////////////////
?>
<html>
<head>
<title><?echo $LANG["Titre"] ?></title>


<link rel="stylesheet" type="text/css" href="style.css" />
<script language="javaScript" src="script.js"></script>

</head>

<body>

	<div align="center">
	<table width="50%" border="0" cellspacing="2" cellpadding="0">
  <tr>
    <td bgcolor="#9CB4C3">
      <table width="100%" border="0" cellspacing="2" cellpadding="2">
        <tr>
          <td bgcolor="#0787A1" align="left" class="texteNoir"><b><?echo $LANG["M_passe"] ?></b></td>
        </tr>
        <tr>
          <td bgcolor="#9CB4C3" class="texteNoir">



<div align="center"><p><br>
<?echo $LANG["S_mdp"] ?><br>

<form action="index.php" method="post">
<?echo $LANG["B_Login"] ?><input type="text"  name="Login"><BR>
<?echo $LANG["B_Password"] ?><input type="password"  name="Passe"><BR>
<input type="submit" value="<?echo $LANG["B_envoyer"] ?>" name="ok">
<BR><BR>
<?if($P_membre=="on") {
	echo"<A Href=membre.php>" . $LANG["Devenir_membre"] ."</A>";
}
?>                                               
</form>
</p></div>
</td></tr>
</table>
</td></tr>
</table>
</div>
	
		 
<?
}
else
{
include("main.inc");



} // fin else general
?>