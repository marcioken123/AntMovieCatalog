################################
#  id�e original: by Willspo   #
#   Script PHP : By Free51     #
#        Version 3.20          #
################################

MODE D'EMPLOI:
-Dezipper le fichier dans un nouveau rep
-copier le fichier 'film.html' dans le rep 'templates' de movie catalog
-ouvir movie catalog
-selectionner exporter catalog en html
-ouvrir le fichier 'film.html' nouvellement copier dans 'templates
-cliquer sur le bouton 'exporter..' et enregistrer le tout sous 'catalog.html' dans le rep '/Data/catalogues/votrerep' du script
-si 1er utilisation, exporter le tout sur votre serveur, ou le rep par defaut de Easyphp si vous l'utilisez,
 sinon copier uniquement le rep '/data/catalogues/votrerep' vers votre serveur.

-Tout ce configure � partir du panneau de config, pour y acceder:
 lancer le script, � l'invite, le login/passe par defaut est: admin/pass.
en bas un gauche du catalogue, un lien existe vers le panneau de configuration.

sinon si vous desactiver le mode mot de passe, vous pouvez vous connecter par l'adresse suivante au panneau de config:
http://votresite.com/conf/index.php, ensuite saisir sont login/pass.

-Vous pourrez � partir de ces pages, ajouter/editer/effacer un utilisateur
 ajouter/editer/effacer un catalogue.
 editer les preferences du template.




-fonctionnement du rating:
dans movie catalog, dans le champ note, mettre 3 pour screener, et 8 pour DVDrip.
je sais c'est pas g�nial, mais j'utilise cette astuce depuis le d�but ;)
sinon pour une utilisation normal du rating(de 1 � 10), dans le fichier config, 3 variables existe,
l'extension de vos images, et la taille largeur/hauteur.Ensuite mettre vos images numeroter de 1 � 10 dans le rep images du script.Par exemple : 1.jpg, 2.jpeg, etc ...


-Pour changer la largeur des colonnes, allez dans le panneau de configuration du template menu preference.

-Pour changer les mots, phrases etc, editer le fichier lang.inc de votre langue et remplacer les termes �  votre convenance.



ENGLISH:
################################ 
# Original Idea: by Willspo    # 
# Script PHP : By Free51       # 
# Version 3.20                 # 
################################ 

HOW TO USE IT: 
- Unzip the file into a new directory 
- Copy the "film.html" file into the templates directory of Movie Catalog 
- Open Movie Catalog 
- Click on the "Export" button and save your export under "catalog.html" into the /Data directory of the script 
- If you use it for the first time, export the whole file structure to your webserver, or to EasyPHP's default directory (if you use it). If you're not using EasyPHP, simply copy the /Data/catalogues/rep directory to your WebServer 
-all configuration of the template this master key in the panel of contr�l, login : admin / password : pass

if you want use this url:
http://yoursite/config/index.html 

HOW THE RATING WORKS: 
- Within movie catalog, use the rating field for indicating if your movie is a Screener (rating=3) or a DVDRip (rating=8)... I know this it not optimal, but I've been using this trick from the beginning 
Otherwise for a use normal of the rating (from 1 to 10), in the config file, 3 variables exist,
The extension of your images, and the size widht/ height. Then put your images numeroter from 1 to 10 in the images folder of the script. For example: 1.jpg, 2.jpeg, etc....


- to change the width of columns, go to template config, menu setting
- to change the words, the sentences etc., edit the file lang.inc of your language and to replace the terms to your liking.


SLOVENSKO:
################################ 
# Originalna Ideja: by Willspo # 
# Script PHP : By Free51       # 
# Version3.20                  # 
################################ 

NAVODILA ZA UPORABO: 
- Odzipajte vsebino datoteke v nov mapo 
- Prekopirajte datoteko "film.html" v mapo /Templates, ki se nahaja v mapi Ant Movie Catalog programa
- Odprite Ant Movie Catalog 
- Kliknite na "Export/Izvozi" gumb in shranite pod imenom "catalog.html" v mapo /Data te skripte 
- �e to skripto uporablajte prvi�, izvozite/prekopirajte celotno datote�no strukturo na va� str�nik, ali v EasyPHP-jevo privzeto mapo (�e ga uporabljate). �e ne uporabljate EasyPHP, enostavno prekopirajte mapo /Data na va� WebServer 

-all configuration of the template this master key in the panel of contr�l, login : admin / password : pass

if you want use this url:
http://yoursite/config/index.html 

KAKO DELUJE RATING: 
- Znotraj Movie Cataloga, uporabite polje rating/ocena za indikacijo ali je va� film Screener (rating/ocena=3) ali DVDRip (rating/ocena=8)... Vem da to ni optimalno, vendar ta trik uporabljam �e od za�etka
Druga�e za obi�ajno rabo rating/ocene (od 1 do 10), v config datoteki obstajajo 3 spremenljivke: za kon�nico grafi�ne datoteke, ter za �irino in vi�ino. Za rabo tega, v mapo /images prekopirajte slike z imeni od 1 do 10 za posamezno oceno. Primer: 1.jpg, 2.jpeg, itd....




- Za zamenjavo besed, stavkov, itd., odprite datoteko lang.inc va�ega jezika in zamenjajte izraze po �elji.

SPANISH
################################
#  Idea original: by Willspo   #
#   Script PHP : By Free51     #
#        Versi�n 3.20          #
################################

INSTRUCCIONES DE USO:
- Descomprimir el archivo en un directorio nuevo.
- Copiar el archivo 'film.html' en el directorio 'templates' del movie catalog.
- Abrir movie catalog.
- Seleccionar la opci�n exportar cat�logo en html.
- Abrir el archivo 'film.html' que hemos copiado antes en 'templates'.
- Apretar en el bot�n exportar 'exportar..' (plantilla entera, no la individual) y guardar con el nombre 'catalog.html' en el directorio '/Data/catalogues/principal' del script.
- Si es la 1� vez, exportar todos los archivos a vuestro servidor web, o el directorio por defecto del Easyphp si es lo que utiliz�is, si no es la 1� vez solo ten�is que copiar el contenido de '/data/catalogues/principal' en el servidor.

- Para configurar todos los par�metros de la web (idioma, pel�culas por p�gina, etc...), pod�is acceder desde:
http://vuestrositio.com/conf/index.php
El usuario y contrase�a por defecto son: admin/pass.
En la parte izquierda est� el men� de configuraciones para poner los par�metros a vuestro gusto.



- Para cambiar las palabras, frases, etc, editar el archivo lang.inc de vuestro idioma y reemplazar los t�rminos convenientes.


CATALAN
################################
#  Idea original: by Willspo   #
#   Script PHP : By Free51     #
#        Versi� 3.20           #
################################

INSTRUCCIONS:
- Descomprimir l'arxiu en un directori nou.
- Copiar l'arxiu 'film.html' en el directori 'templates' del movie catalog.
- Obrir movie catalog. 
- Seleccionar l'opci� exportar cat�leg en html.
- Obrir l'arxiu 'film.html' que hem copiat abans en 'templates'.
- Pr�mer el bot� exportar 'exportar..' (plantilla sencera, no la individual) i guardar amb el nom 'catalog.html' en el directori '/Data/catalogues/principal' del script.
- Si �s la 1� vegada, exportar tots els arxius al vostre servidor web, o al directori per defecte del Easyphp si �s el que utilitzeu, si no �s la 1� vegada sols heu de copiar el contingut de '/data/catalogues/principal' al servidor. 

- Per a configurar tots els par�metres de la web (idioma, pel�l�cules per p�gina, etc...), podeu accedir des de: 
http://vuestrositio.com/conf/index.php 
L'usuari i contrassenya per defecte s�n: admin/pass. 
En la part esquerra est� el men� de configuracions per a posar els par�metres al vostre gust. 




- Per canviar les paraules, frases, etc, editar l'arxiu lang.inc del vostre idioma i reempla�ar els termes convenients.