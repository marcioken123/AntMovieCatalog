<?session_start();
////////////////////////////////////////////////////////////////
//  Fichier : View.php
//  Version Template-PHP : 3.X
//  Release : 103
//  Date : 05/11/03
//  De : Free51  / Free51@passions-numerique.net
//
////////////////////////////////////////////////////////////////


foreach( $_ENV as $e => $f )
 {
 $$e = $f;
 }
 foreach( $_SERVER as $e => $f )
 {
 $$e = $f;
 }
 foreach( $_REQUEST as $e => $f )
 {
 $$e = $f;
 }
foreach( $_SESSION as $e => $f )
 {
 $$e = $f;
 }

if(session_is_registered('Pass')) {
global $valeur,$Pass,$description,$V_Ncd,$Add,$Add_yes;
include("conf/config.dat");
include "lang/lang.".$lang.".inc";


 


$fd = fopen ($Catalogue, "r");  
				 while (!feof ($fd)) {    
				 $buffer =  fgetcsv ($fd, 2048, ";");  
				  
				 
				  if($buffer[0]=="number" and $buffer[1]==$fiche) {
				  
				 
				  while($buffer[0]!="[*]") {
				  $buffer =  fgetcsv ($fd, 2048, ";");
				  
				  
				  
				  if($buffer[0]=="date") {
				  	$dat=$buffer[1]; 
				   }
				  
				   if($buffer[0]=="Format") {
				  	$format=$buffer[1]; 
				   }
				   
				   if($buffer[0]=="source") {
				  	$source=$buffer[1]; 
				   }
				   
				   if($buffer[0]=="disk") {
				  	$ndisk=$buffer[1]; 
				   }
				  if($buffer[0]=="sound") {
				  	$fson=$buffer[1]; 
				   }
				  
				  if($buffer[0]=="title") {
				  	$titre=$buffer[1]; 
				   }
				  
				  
				  if($buffer[0]=="year") {
				  	$annee=$buffer[1]; 
				   }
				 
				   if($buffer[0]=="duree") {
				  	$durer=$buffer[1]; 
				   }
				 
				   if($buffer[0]=="category") {
				  	$categorie=$buffer[1]; 
				   }
				  
				   if($buffer[0]=="director") {
				  	$realisateur=$buffer[1]; 
				   }
				  
				   if($buffer[0]=="producer") {
				  	$producteur=$buffer[1]; 
				   }				  
				  
				   if($buffer[0]=="picture") {
				  	$picture=$buffer[1]; 
				   }
				  
				   if($buffer[0]=="actors") {
				  	$acteur=$buffer[1]; 
				   }
				    if($buffer[0]=="siteurl") {
				  	$Siteurl=$buffer[1]; 
				   }
				  
				   if($buffer[0]=="rating") {
				  	$rang=$buffer[1]; 
				   }
				  
				   if($buffer[0]=="country") {
				  	$pays=$buffer[1];
				   }
				   
				   if($buffer[0]=="Langue") {
				  	$languef=$buffer[1]; 
				   }
				  
				  	if($buffer[0]=="description") {
				  	
					while($buffer[0]!="[*]") {
					if($buffer[0]=="description"){
						$description=$description.$buffer[1]; 
						}
						else
						{
						$description=$description.$buffer[0]; 
						}
						$buffer =  fgetcsv ($fd, 2048, ";");
						if($buffer[0]=="[fin]") {
						break 2;
						}
					}
					
				   }
				  
				
				  
				
				  
				 } // fin du while [*]
			} // fin du test fiche
			
			}  // fin du while lire fichier
			fclose ($fd);

///////////////// ADD ////////////////////////////
if($Add=="yes") {
	$fichier="data/panier/demande.dat";
	$op_file = fopen($fichier,"a+");
		$value=$fiche . ";" . $titre . ";" . $Pass .";" . "\n";
		
		fputs($op_file,$value);				
	fclose($op_file);
}

?>
<html>
<head>
<title>--  <? echo $LANG["V_Titreinfo"] . " " . $titre ?> --</title>
<link rel="stylesheet" type="text/css" href="style.css" />


<script language="javaScript" src="script.js"></script>

</head>

<body >


<table class="infoViewTable" height="100%" width="100%" cellpadding="0" cellspacing="0" border="0">
<tr>
		<td class="infoViewTable" valign="top" width="333">
			<img src="<? echo $Ch_catalog.$picture ?>" class="largePicture" >
		</td>
<td valign="top" class="infoViewTable">
		<div class="infoViewText">
		
			<p class="infoView">
			<span class="largeTitle">
				<? echo $titre ?>
			</span>
			<?if($rang!="") { ?>
				<img src="images/<? echo $rang.$Ext_image; ?>" border="0" width="<?echo $Taille_W ?>" height="<?echo $Taille_H ?>" alt=""> 
			<? } ?>
			
			</p><p class="infoView">
			<b><?echo $LANG["V_Dateajout"] ?></b>&#160;<?echo $dat ?>
			<br class="infoViewTable" />
			<b><?echo $LANG["V_Categorie"] ?></b>&#160;<?echo $categorie ?>
			<br class="infoViewTable" />
			<b><?echo $LANG["V_Source"] ?></b>&#160;<?echo $source ?>,&#160;<?echo $ndisk ?> <?echo $V_Ncd ?>
			<br class="infoViewTable" />
			<b><?echo $LANG["V_Formatvideo"] ?></b>&#160;<?echo $format ?>
			<br class="infoViewTable" />
			<b><?echo $LANG["V_Formatson"] ?></b>&#160;<?echo $fson ?>
			<br class="infoViewTable" />
			<b><?echo $LANG["V_Production"] ?></b>&#160;<?echo $pays ?>,&#160;<? echo $annee ?>
			<br class="infoViewTable" />
			<b><?echo $LANG["V_Duree"] ?></b>&#160;<?echo $durer ?> <?echo $LANG["V_min"] ?>
			<br class="infoViewTable" />
			<b><?echo $LANG["V_Realisateur"] ?></b>&#160;<?echo $realisateur ?>
			<br class="infoViewTable" />
			<b><?echo $LANG["V_langue"] ?></b>&#160;<?echo $languef ?>
			</p><p class="infoView">
			<b><?echo $LANG["V_acteur"] ?></b><br />
			<?
			
			$Tab_Acteur=explode(",", $acteur);
			for($num=0; $num < count($Tab_Acteur); $num++) {
				$select=ereg_replace(" ","%20",$Tab_Acteur[$num]);
				echo"<a href=index.php?guide=tout&recherche=rec&valeur=$select target=_blank class=filter>$Tab_Acteur[$num]</A><BR>";
			
			
			}
			
			
			
			
			
			?>
			</p>
			<p class="infoView">
			<b><?echo $LANG["V_Description"] ?></b><br /><?echo $description ?>
			</p>
			
			
			<table border="0" width="100%">
   					<tr>
   					<td width="50%"><? if($Siteurl!="") { 
			echo"<BR><table><tr><td><b><p class=infoView>".$LANG["V_Siteweb"]."</p><B><A Href=\"$Siteurl\" target=\"_blank\" class=filter>$titre</a></td></tr></table>";
			}
			?></td>
   					<td><div align="right">
			<? if($S_panier=="on" and $Add!="yes") { 
			$fd = fopen ("data/panier/demande.dat", "r");
			while (!feof ($fd)) {    
					$Buffers =  fgetcsv ($fd, 2048, ";");
						if($Buffers[0]==$fiche) {
						$Add_yes="on";
								
						}
			}
			fclose($fd);
			
			$fd = fopen ("data/panier/encours.dat", "r");
			while (!feof ($fd)) {    
					$Buffers =  fgetcsv ($fd, 2048, ";");
						if($Buffers[0]==$fiche) {
						$Add_yes="on";
								
						}
			}
			fclose($fd);
			}			
				if($Add_yes!="on" and $Add!="yes") {				
					?>
			<A HREF="view.php?fiche=<? echo $fiche ?>&Add=yes"><img src="images/addpanier.gif"></A>
			
			
			<?
				}
				else
				{
				echo "<i><font size=2 color=\"#ff0000\">" . $LANG["V_Reserver"]	 ."</font></i>";
				}
			
			
			
			?> 
			</div></td>
   					</tr>
   			</table>
   
			
			
			
		</div>
		<p align="right" style="margin-top:10px;padding:0px;">
		<a class="button" href="javascript:window.print()"><?echo $LANG["V_imprimer"] ?></a>
		<a class="button" href="javascript:window.close()"><?echo $LANG["V_Fermer"] ?></a>
		
		</p>
			
		
		</td>
		</tr>
</table>






</body>
</html>

<?
} // fin de la session
?>
	