-----------------------------------------------------------------------------------------------------------

.==.
 :   ' <<<< /\
  "==<)))))):                         TEMPLATE FOR PDA BY ScorEpioN
       <<<< \_/

-----------------------------------------------------------------------------------------------------------
                                         Contenu du fichier ZIP
-----------------------------------------------------------------------------------------------------------

> PDA_template_full.html // Liste compl�te
> PDA_template_full_recherche.html // Moteur de recherche et r�sultats
> PDA_template_indiv.html
> amc-logo.gif
> appr0.gif, appr1.gif, appr2.gif, appr3.gif, appr4.gif
> favicon.bmp, favicon.ico

-----------------------------------------------------------------------------------------------------------
                                         Utilisation du template
-----------------------------------------------------------------------------------------------------------

*************************************** Export de votre catalogue : ***************************************

1�) Menu "Fichier"
2�) "Exporter"
3�) "HTML"
4�) Dans "Complet", choisir "PDA_template_full.html" ou "PDA_template_full_recherche.html"
5�) Dans "Individuel", choisir "PDA_template_indiv.html"
6�) Cliquer sur "Exporter" (Attention au choix du nom du catalogue, si sample.amc -> sample.amc.html)
7�) Penser � copier les fichiers "amc-logo.gif", "favicon.bmp", "favicon.ico" dans le m�me r�pertoire
8�) Copier le tout sur votre PDA.


******************************** Pour que la fonction recherche fonctionne ********************************

Il se peut que la fonction "Recherche" ne fonctionne pas. Il y a deux raisons possible :

1�) Un probl�me dans le nom du fichier HTML
> Le nom du catalogue doit �tre le m�me que celui du fichier html (Sample.amc -> Sample.amc.html).
OU
> Modifier dans "PDA_template_full_recherche.html", "$$FILENAME.html" par le nom de votre page HTML.

2�) Un des champs dans lequel la fonction recherche est effectu� comporte un double quote "
> La seule solution pour que la fonction recherche marche est de lancer le script UPDATE FIELDS.
> Utiliser la fonction "Remplacer un mot dans un champs"
> Choisir le champs ACTEURS (c'est souvent l� qu'il y a un probl�me).
> Mot � remplacer " (SHIFT+3)
> Nouveau mot '' (deux foix SHIFT+4)

******************************* Le nom affich� en ent�te de la page princpale *****************************

1�) Menu "Fichier"
2�) "Propri�t�s"
3�) "Nom"

***************************** Pour un affichage correct des images et des textes **************************

1�) Menu "Outils"
2�) "Pr�f�rences"
3�) "Exportation"
4�) "Forcer la taille des images avec les attributs : " width = 200 & height = 280

-----------------------------------------------------------------------------------------------------------
              A faire pour pouvoir continuer � utiliser Pocket Word et Pocket Excel normallement
-----------------------------------------------------------------------------------------------------------

*********************************************** Manipulation **********************************************

Il faut cr�er un r�pertoire "\My Documents" � la racine de la carte m�moire externe.

Supprimer le fichier "ignore_my_docs" qui se trouve � la racine de la carte m�moire externe.

******************************************* Comment faire cela ? ******************************************

Soit en ins�rant votre Pocket PC sur son socle et en utilisant l'explorateur de votre PC, � condition qu'il
soit configur� pour voir les fichiers cach�s. Soit en effectuant un appui prolong� dans la zone blanche qui
se trouve sous la liste des fichiers de l'explorateur du Pocket PC et en cliquant sur
"Afficher tous les fichiers".

*********************************************** Pourquoi ? ************************************************

Les applications Pocket PC 2002 voient ce fichier cach� et commencent � inspecter la carte de stockage
syst�matiquement. Ce peut �tre particuli�rement p�nible si votre carte est de grande capacit� avec des
centaines de fichiers dans des sous-r�pertoires. Si le fichier "ignore_my_docs" existe, PocketExcel ou
PocketWord vont parcourir l'ensemble de la carte � la recherche de leurs fichiers. Si vous avez
un microdrive de 1Go assez bien rempli, pr�parez-vous � aller prendre un caf� le temps que votre machine
vous rende la main.
