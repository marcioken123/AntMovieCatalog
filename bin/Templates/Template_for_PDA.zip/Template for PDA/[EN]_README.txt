-----------------------------------------------------------------------------------------------------------

.==.
 :   ' <<<< /\
  "==<)))))):                         TEMPLATE FOR PDA BY ScorEpioN
       <<<< \_/                         Sorry for my bad english

-----------------------------------------------------------------------------------------------------------
                                         Contents of the ZIP file
-----------------------------------------------------------------------------------------------------------

> PDA_template_full.html // Liste compl�te
> PDA_template_full_recherche.html // Moteur de recherche et r�sultats
> PDA_template_indiv.html // La fiche d�taill�e
> [EN]_PDA_template_full.html // Complete list of movies
> [EN]_PDA_template_full_recherche.html // Search engine and results
> [EN]_PDA_template_indiv.html // the detailed card
> amc-logo.gif
> appr0.gif, appr1.gif, appr2.gif, appr3.gif, appr4.gif
> favicon.bmp, favicon.ico

-----------------------------------------------------------------------------------------------------------
                                         HOW TO USE TEMPLATE
-----------------------------------------------------------------------------------------------------------

****************************************** Export your catalog : ******************************************

1�) Menu "File"
2�) "Export"
3�) "HTML"
4�) "FULL", choose "[EN]_PDA_template_full.html" or "[EN]_PDA_template_full_recherche.html"
5�) Dans "Individual", choose "[EN]_PDA_template_indiv.html"
6�) Click on "Export" (Be carefull : html name need to be "catalog name".amc.html)
7�) Copy "amc-logo.gif", "favicon.bmp", "favicon.ico" in same directory
8�) Copy all the directory content in your PPC.


******************************************** Use Search engine ********************************************

If search engin failed :

1�) look HTML name
> catalog name same as html file name (Sample.amc -> Sample.amc.html).
OR
> Modify "[EN]_PDA_template_full_recherche.html", "$$FILENAME.html" -> HTML file name.

2�) One field contents "
> Use my script UPDATE FIELDS.
> Use "Replace a word" fonction
> Choose the "Actors" field (it's ofen the source of the problem).
> Mot � remplacer " (SHIFT+3)
> Nouveau mot '' (twice SHIFT+4)

************************************** Name on the top of the FULL page ***********************************

1�) "File"
2�) "Properties"
3�) "Name"

************************************************ A good display *******************************************

1�) "Tools"
2�) "Preferences"
3�) "Export"
4�) "Force picture size by adding attributes" width = 200 & height = 280

-----------------------------------------------------------------------------------------------------------
                                     If Pocket Word and Pocket Excel open slowly
-----------------------------------------------------------------------------------------------------------

Create a directory "\My Documents" on the top of your memory card.

Delete the file "ignore_my_docs" on the top of your memory card.
