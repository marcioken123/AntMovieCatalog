Twinks Template for AMC
BETA 0.8

USING THE TEMPLATE
Now that this uses XML movies database support it's a bit
different to setup, no longer do you need to use the export
function.  Just copy all files to your 'export' directory
and save your movie list in XML format in the directory
(File -> Save As -> *.XML (Drop down box) ) called movies.xml.
then open "Movies.html", it will read the xml file and display
your movies. 


COPY TO EXPORT DIRECTORY
* /themes/*
* /pics/*
* layoutX.xml (where X is 1 to 4)
* Movies.html (Rename to whatever you like)


CUSTOMIZING THE TEMPLATE
There are several ways of customzing this template.

THEMES
Using the .css files found in the /themes/ directory
the colors of the table and buttons can be changed.
Several themes/styles are released with the template.
In Mozilla or Netscape, when the exported movie list
is opened, you can change style on the fly by selecting
View -> Use Style -> Style Name.  However this isn't
possible in Internet Explorer, it can only use the
default style.  You can change the default style by
changing the lines 

<link title ="Light" rel="stylesheet" type="text/css" href="themes/light.css">
<link title ="Dark" rel="alternate stylesheet" type="text/css" href="themes/dark.css">

to 

<link title ="Light" rel="alternate stylesheet" type="text/css" href="themes/light.css">
<link title ="Dark" rel="stylesheet" type="text/css" href="themes/dark.css">

note there are more then two styles available, set the
desired styles rel attribute to "stylesheet" and all
the others to "alternate stylesheet".

You can make your own styles, by copying the .css file
and editing the color values in it to suit your need.
You may also want to set the pictures used for the toolbar
in there.

LAYOUT.XML
To customize what information about the movie is shown you
have to use the Layout XML files.  To start with change the
var xmllayout = "layout1.xml"; line in the template to any
other layout.xml file ie layout3.xml. Export the template
and see what it looks like.

If you look at the contents of the XML files, compared to what
they display, you should be able to figure out how to use them
or at least be able to copy and paste bits you want.

FIELDS (For Layout.XML)

OriginalTitle, TranslatedTitle, Number, Date
Rating, Category, Director, Actors, Country
Languages, Subtitles, Year, Length, URL
Description, Comments, Disks, VideoFormat
VideoBitrate, AudioFormat, AudioBitrate
Resolution, Framerate, Size, Source
MediaLabel, MediaType, Borrower, Producer
Checked.

ON THE FLY
Using the options dialog while viewing the exported template you
can change the look quite a bit, however none of these changes
are perminant.


HISTORY

NEW IN 0.8
* Separated Javascript, HTML and Movies (Movies now in Movies.XML)
* Setting maxPerPage to 0 shows all movies in the category
* Ability to dynamically change layout (Choose Layout.xml in options)
* Shows sorted field (Small Triangle in Column Title)
* Buttons & InputText are now skinned (Thanks Willspo)
* Added Sorton field to Options in Layout.xml files (Original Sorting)
* Added Searchon field to Options in Layout.xml files (Fields that are searched on)
* Action Field in Layout.xml can hide/show multiple rows now (Layout2.xml does this)
* Popup Info using new popup action field in Layout.xml (Layout3.xml does this.  Thanks to Willspo)
* Fixed the Quotation bug (By Using XML Movie Format)
* Fixed Groups with spaces in their name (ie New Zealand => New_Zealand)
* Fixed Column spans
* Fixed Sorting by numbers
* Fixed First Click Sort
* Fixed Click Text not Cell
* Character "|" is converted to <BR> (as AMC does opposite for saving to XML)

SO FAR
* Group by any field (With "(All)", "(None)" and "(Search)" support)
* Supports Multiple Categories/Groups for each movie 
* Split into Pages of X Movies 
* Options, Info and About Dialogs
* Sort on any field
* Expandable Info
* Search on any field
* CSS Themes/Styles
* Mozilla and Internet Explorer Support
* Ratings using 5 starts, each half star being 1/10 (Thanks to Bad Joker) 
* Custom Layouts using the Layout.xml files