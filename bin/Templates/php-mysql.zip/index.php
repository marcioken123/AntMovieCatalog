<?php
  include("settings.php");
?>
<html>
<head>
<LINK REL="stylesheet" href="movies.css" TYPE="text/css">
</head>
<body>
<p align="center"><font size="+2">Movies</font></p>
<hr>
<?php
  mysql_pconnect($sql_server, $sql_user, $sql_password);
?>
<p align="center">Currently there is <b><?php
	$resultat = mysql_db_query($sql_basename, "SELECT COUNT(NUM) FROM $sql_tablename");
	if ($enr = mysql_fetch_array($resultat)) echo $enr[0];
	else echo "0";
?></b> movies in the list. Select options then click on "Display list".</p>
<hr>
<FORM METHOD="post" ACTION="list.php" NAME="listoptions">
<table border="0" cellpadding="0" cellspacing="0" align="center">
<tr>
<td valign="top">
	<p>Include fields :</p>
	<p><blockquote>
		<input type=checkbox checked name="NUM">Number<br>
		<input type=checkbox checked name="ORIGINALTITLE">Original Title<br>
		<input type=checkbox checked name="TRANSLATEDTITLE">Translated Title<br>
		<input type=checkbox  name="COUNTRY">Country<br>
		<input type=checkbox  name="CATEGORY">Category<br>
		<input type=checkbox  name="YEAR">Year<br>
		<input type=checkbox  name="LENGTH">Length<br>
		<input type=checkbox  name="VIDEOFORMAT">Video format<br>
		<input type=checkbox checked name="LANGUAGES">Language<br>
		<input type=checkbox checked name="SUBTITLES">Subtitles<br>
		<input type=checkbox  name="RESOLUTION">Resolution<br>
		<input type=checkbox  name="FILESIZE">Files sizes<br>
		<input type=checkbox checked name="DESCRIPTION">Description<br>
		<input type=checkbox  name="IMAGE">Picture
	</blockquote></p>
</td>
<td width="30">&nbsp;</td>
<td valign="top">
	<p>Sort order :</p>
	<p><blockquote>
		<input type=radio name=SORTORDER value=0 checked>By number<br>
		<input type=radio name=SORTORDER value=1 >By original title<br>
	</blockquote></p>
</td>
</tr>
<tr><td colspan="3" align="center" valign="bottom" height="50">
	<p>
		<input type=submit value="   Display List   ">
	</p>
</td>
</tr>
</table>
</form>
</body>
</html>
