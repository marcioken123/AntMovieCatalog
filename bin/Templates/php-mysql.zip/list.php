<?php
  include("settings.php");
?>
<html>
<head>
<LINK REL="stylesheet" href="movies.css" TYPE="text/css">
</head>
<body>
<p align="center"><font size="+2">Movies</font></p>
<hr>
<p align="center"><a href="index.php">Back to settings</a></p>
<hr>
<?php
	$fieldscount=0;
	$requete="SELECT NUM, ORIGINALTITLE, TRANSLATEDTITLE";
	if($COUNTRY) $requete.=", COUNTRY";
	if($CATEGORY) $requete.=", CATEGORY";
	if($YEAR) $requete.=", YEAR";
	if($LENGTH) $requete.=", LENGTH";
	if($DESCRIPTION) $requete.=", DESCRIPTION";
	if($VIDEOFORMAT) $requete.=", VIDEOFORMAT";
	if($LANGUAGES) $requete.=", LANGUAGES";
	if($SUBTITLES) $requete.=", SUBTITLES";
	if($RESOLUTION) $requete.=", RESOLUTION";
	if($SIZE) $requete.=", SIZE";
	if($IMAGE) $requete.=", PICTURENAME";
	$requete.=" FROM $sql_tablename ORDER BY ";
	if(($SORTORDER == "1") && ($ORIGINALTITLE))
	{
		$requete.="ORIGINALTITLE";
  } else {
		$requete.="NUM";
	}
	echo "<table class=\"blk\" border=\"1\" cellspacing=\"0\" cellpadding=\"5\"><tr>";
	if($NUM) {
		echo "<td nowrap>Number</td>";
	}
	if($ORIGINALTITLE) {
		echo "<td nowrap>Original title</td>";
		$fieldscount++;
	}
	if($TRANSLATEDTITLE) {
		echo "<td nowrap>Translated title</td>";
		$fieldscount++;
	}
	if($COUNTRY) {
		echo "<td nowrap>Country</td>";
		$fieldscount++;
	}
	if($CATEGORY) {
		echo "<td nowrap>Category</td>";
		$fieldscount++;
	}
	if($YEAR) {
		echo "<td nowrap>Year</td>";
		$fieldscount++;
	}
	if($LENGTH) {
		echo "<td nowrap><Length</td>";
		$fieldscount++;
	}
	if($FORMAT) {
		echo "<td nowrap>Video format</td>";
		$fieldscount++;
	}
	if($LANGUAGES) {
		echo "<td nowrap>Language</td>";
		$fieldscount++;
	}
	if($SUBTITLES) {
		echo "<td nowrap>Subtitles</td>";
		$fieldscount++;
	}
	if($RESOLUTION) {
		echo "<td nowrap>Resolution</td>";
		$fieldscount++;
	}
	if($SIZE) {
		echo "<td nowrap>Files sizes</td>";
		$fieldscount++;
	}
	echo "</tr>\n";
  mysql_pconnect($sql_server, $sql_user, $sql_password);
	$resultat = mysql_db_query($sql_basename, $requete) or die(mysql_error());
	while ($enr = mysql_fetch_array($resultat)) {
		echo "<tr>";
		if($NUM || $IMAGE) {
			echo "<td rowspan=\"2\" class=\"lgt\">";
			if($NUM) {
				echo "<b>".$enr['NUM']."</b>";
				if($IMAGE) echo "<br>";
			}
			if($IMAGE) {
				$imagefile=$enr['PICTURENAME'];
				if($imagefile!="") echo "<img src=".$imagefile.">";
			}
			echo "&nbsp;</td>";
		}
		if($ORIGINALTITLE) {
			echo "<td class=\"lgt\">".$enr['ORIGINALTITLE']."&nbsp;</td>";
		}
		if($TRANSLATEDTITLE) {
			echo "<td class=\"lgt\">";
			if(!$ORIGINALTITLE && $enr['TRANSLATEDTITLE']=="") echo $enr['ORIGINALTITLE'];
			else echo $enr['TRANSLATEDTITLE'];
			echo "&nbsp;</td>";
		}
		if($COUNTRY) {
			echo "<td class=\"lgt\">".$enr['COUNTRY']."&nbsp;</td>";
		}
		if($CATEGORY) {
			echo "<td class=\"lgt\">".$enr['CATEGORY']."&nbsp;</td>";
		}
		if($YEAR) {
			echo "<td class=\"lgt\">".$enr['YEAR']."&nbsp;</td>";
		}
		if($LENGTH) {
			echo "<td class=\"lgt\">".$enr['LENGTH']."&nbsp;</td>";
		}
		if($FORMAT) {
			echo "<td class=\"lgt\">".$enr['FORMAT']."&nbsp;</td>";
		}
		if($LANGUAGES) {
			echo "<td class=\"lgt\">".$enr['LANGUAGES']."&nbsp;</td>";
		}
		if($SUBTITLES) {
			echo "<td class=\"lgt\">".$enr['SUBTITLES']."&nbsp;</td>";
		}
		if($RESOLUTION) {
			echo "<td class=\"lgt\">".$enr['RESOLUTION']."&nbsp;</td>";
		}
		if($SIZE) {
			echo "<td class=\"lgt\">".$enr['SIZE']."&nbsp;</td>";
		}
		echo "</tr>";
		if($DESCRIPTION) {
			echo "<tr><td colspan=\"".$fieldscount."\" class=\"lgt\">".$enr['DESCRIPTION']."&nbsp;</td></tr>";
		}
		echo "<tr><td colspan=\"".($fieldscount+1)."\" class=\"blk\"></td></tr>\n";
	}
	echo "</table>";
?>
</body>
</html>
