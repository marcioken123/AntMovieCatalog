<?php
  $sql_server = "127.0.0.1";
  $sql_user = "root";
  $sql_password = "";
  $sql_basename = "test";
  $sql_tablename = "films";
?>
