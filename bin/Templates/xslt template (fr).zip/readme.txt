-----------------------------------------
|					|
|	Template by Willspo		|
|	wille@tegenaria.com             |
|  //Traduit + modif By Free51\\        |		|
|					|
-----------------------------------------

Dezipper le fichier template_xml.zip dans un rep de votre choix


Install
-----------------------------------------
1.D�marrer movie catalog
2.Exporter en html avec l'option complet + image
3.Selectionner le fichier data/liens.html
4.Sauvegarder sous 'movies.xml' tj dans le rep data
5.lancer votre script avec votre navigateur



il a 2 fichiers index � la racine du template

- index.html pour une consultation direct du catalogue en ligne
- index.php auquel j'ai ajouter un script d'ouverture de session(si votre serveur le permet) avec un mot de passe, pour le changer rien de plus simple, editer le fichier index.php(avec le bloc note ca suffit), trouver la ligne:

if($pw=="passe"){

changer 'passe' par ce que vous voulez ;)

#astuce, sur la page, quand le script vous demande le mot de passe,tapez le mot de passe et ne faite pas entrer, cliquez sur 'envoyer'.






Run
-----------------------------------------
Run index.html 		if you want to show your movie info in Internet Explorer
Run index.hta 		if you want to be able to launch movies from your moive list
Run index_tv.hta	if you want to view the list on a tv (with 800x600 res)

!! For the play function to work you have to modify the first line in play.js (open in notepad)
var cdDriveLetter = 'e'; (change e to your cd-drive letter)


