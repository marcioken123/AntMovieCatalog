I used for tests IE 6 and Opera 7.** and it works :-)
Code is very unclear but this is my first time (Please forgive me :-) )
In order to build that code i used some elements from someone else's scripts. (thank you :-) ) 
Sorry for my English.
Contact: ketchuppp@wp.pl