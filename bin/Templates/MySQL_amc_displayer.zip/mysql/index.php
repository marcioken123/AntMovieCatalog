<?php 
/*----------------------------------------------------*/
/*                 FICHIER PRINCIPAL                  */
/*----------------------------------------------------*/
include("inc.config.php"); 
?>
<html><head><title><?=$config['titre']?></title>
<link href="style.css" rel="stylesheet" type="text/css" />
<script type="text/javascript">
function test_search(){
	if(document.search.query.value==""){
		alert('Recherche impossible sur une requete vide.');
		return false;
	}else{
		return true;
	}
}
function test_mail(){
	if(document.emprunts.nom.value==""){
		alert('Veuillez indiquer votre nom complet.');
		return false;
	}else{
		if(document.emprunts.email.value==""){
			alert('Veuillez indiquer votre adresse e-mail.');
			return false;
		}
	}
	return true;
}
function pop(id){
	window.open('detail.php?id='+id,'D�tails','width=750,height=480,resizable=yes,scrollbars=yes');
}
</script>
</head>
<body>

<p class="title" align="center">
  <?=$config['titre']?>
</p>

<p align="center">
  <?=$config['soustitre']?>
</p>

<p align="center">
  <a href="?">R�initialiser tous les crit�res d'affichage</a> - <a href="refresh.php">Actualiser la base de donn�es</a>
  <?php if(isset($_GET['refresh'])){ echo "<span style=\"color: #FF0000;\">".$_GET['refresh']."</span>"; } ?>
</p>


<br/>


<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td>
      Pour toute suggestion, <a href="mailto:<?=$config['contact']?>">contactez-moi</a>.<br />
      Pour emprunter, faites votre choix puis voyez <a href="#foot">en bas</a>.<br />
      Pour plus de d�tails sur un film, cliquez sur son titre.
    </td>

<?php
if(isset($_GET['orderby'])){
	$tri=$_GET['orderby'];
}else{
	$tri="TranslatedTitle";
}
if(isset($_GET['sens'])){
	$sens=$_GET['sens'];
}else{
	$sens="ASC";
}
if(isset($_GET['debut']) && isset($_GET['fin'])){
	$limit="LIMIT ".$_GET['debut'].",".$_GET['fin'];
}else{
	$limit="";
}

if(isset($_GET['query']) && isset($_GET['champ'])){
	$cond=" WHERE `".$_GET['champ']."` LIKE '%".str_replace("+", "%", str_replace(" ", "%", trim($_GET['query'])))."%'";
	$supp="&query=".trim($_GET['query'])."&champ=".$_GET['champ'];
}else{
	$supp=""; $cond="";
}

function boutons_tri($CHAMP){
	global $supp, $tri, $sens;
	$h="<img src=\"ico/haut.gif\" alt=\"Trier cette colonne par ordre croissant\" border=\"0\">";
	$b="<img src=\"ico/bas.gif\" alt=\"Trier cette colonne par ordre d�croissant\" border=\"0\">";
	if($tri==$CHAMP){
		if($sens=="DESC"){
			return "<a href=\"?orderby=$tri&sens=ASC$supp\">".$h."</a>";
		}else{
			return "<a href=\"?orderby=$tri&sens=DESC$supp\">".$b."</a>";
		}
	}else{
		return "<a href=\"?orderby=$CHAMP&sens=ASC$supp\">".$h."</a> <a href=\"?orderby=$CHAMP&sens=DESC$supp\">".$b."</a> ";
	}
}

?>
    <td align="right">
      <form method="get" action="index.php" name="search">
        <input type="text" name="query" size="30">
        <select name="champ">
          <option value="TranslatedTitle">Titre traduit</option>
          <option value="OriginalTitle">Titre original</option>
          <option value="Description">R�sum�</option>
          <option value="Borrower">Emprunteur</option>
          <option value="Category">Genre</option>
          <option value="Country">Origine</option>
          <option value="Actors">Acteurs</option>
          <option value="Director">R�alisateur(s)</option>
        </select>
        <input type="submit" name="submit" value="Rechercher" onClick="return test_search()">
      </form>
    </td>
  </tr>
</table>


<form name="emprunts" method="post" action="<?=$config['dest_form']?>">


<?php 
if(isset($_GET['query']) && isset($_GET['champ'])){
	echo "<p align=\"center\" style=\"color: red; \">Recherche de \"<b>".htmlspecialchars($_GET['query'])."</b>\" dans <b>".$_GET['champ']."</b> :</p>"; 
}else{ 
	echo "<br>"; 
} 
?>


<table class="blk" border="1" cellspacing="0" cellpadding="5">
  <tr>
    <td class="blk" nowrap>
      <?=boutons_tri("Number"); ?> R�f.
    </td>
    <td class="blk" nowrap>
      <?=boutons_tri("TranslatedTitle"); ?> Titre fran�ais (titre original)
    </td>
    <td class="blk" nowrap>
      <?=boutons_tri("Borrower"); ?> Emprunteur
    </td>
    <td class="blk" nowrap width="2%">
      <?=boutons_tri("Category"); ?> Genre
    </td>
  </tr>

<?php 
$requete = "SELECT * FROM `".$config['table']."`$cond ORDER BY `$tri` $sens $limit ";
$result = mysql_query($requete) or die(mysql_error());
$i = mysql_num_rows($result); //nombre de films
while ($row = mysql_fetch_array($result)) { ///////////////////////////////DEBUT LISTE
?>
  <tr>
    <td width="10%">
      <input 
        type="checkbox" 
        name="emprunt[]" 
        value="<?="DX".$row['Number']." : ".$row['TranslatedTitle']." (".$row['OriginalTitle'].")"?>"
        <?=($row['Borrower']!=""?" disabled=\"true\"":"")?>
      >
      DX<?=$row['Number']?>
    </td>
    <td width="60%">
      <strong><a href="javascript:pop(<?=$row['Number']?>)"><?=$row['TranslatedTitle'];?></a></strong>
      <?php 
        if(strtolower($row['OriginalTitle'])!=strtolower($row['TranslatedTitle'])){ 
        	echo " (".$row['OriginalTitle'].")"; 
        } 
      ?>
    </td>
    <td style="color: red" width="15%">
      <?php 
	if($row['Borrower']==""){
		echo "&nbsp;";
	}else{
		echo str_replace(
			"Pas encore grav�",
			"<i style=\"color: #AAAAAA\">Pas encore grav�</i>",
			str_replace(
				"Inconnu",
				"<i style=\"color: #AAAAAA\">Inconnu</i>",
				$row['Borrower']
			)
		);
	}
      ?>
    </td>
    <td width="15%" nowrap="nowrap">
      <?php 
	if($row['Category']==""){ 
		echo "&nbsp;"; 
	}else{ 
		echo $row['Category']; 
	}
      ?>
    </td>
  </tr>
<?php 
} /////////////////////////////////////////////////////////////////////////FIN LISTE
?>
</table>
<p><a name="foot"><strong>Total : <?=$i; ?> films.</strong></a></p>
<p>
  Pour emprunter, cochez les films d�sir�s, remplissez les deux champs ci-dessous puis validez.
</p>
<table border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td>
      Votre nom complet : 
    </td>
    <td>
      <input type="text" name="nom">
    </td>
  </tr>
  <tr>
    <td>
      Votre e-mail : 
    </td>
    <td>
      <input type="text" name="email">
    </td>
  </tr>
  <tr>
    <td>
      Commentaires (ou, quand, comment,...) : 
    </td>
    <td>
      <input type="text" name="commentaires" size="50">
    </td>
  </tr>
</table>
<input type="submit" value="Demander � emprunter la s�lection" onClick="return test_mail();">

</form>

<p align="right">
  <a href="#top">Remonter au d�but</a>
</p>
<p>
  Liste �dit�e par <a href="mailto:<?=$config['contact']?>"><?=$config['vous']?></a>
</p>
<p style="font-size: 11px; text-align: center;">
  Script by <a href="http://www.mout.fr" target="_blank">MOutOn Productions</a>
   | Special thanks to <a href="http://www.antp.be/software/moviecatalog/fr" target="_blank">Ant Movie Catalog</a>
  <br />
  <br />
</p>
</body>
</html>
