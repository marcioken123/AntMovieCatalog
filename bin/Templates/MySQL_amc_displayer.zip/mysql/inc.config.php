<?php
/*          SCRIPT FAIT PAR Antoine Rousseau          */
/*               mouton_85@hotmail.com                */
/*----------------------------------------------------*/


/*---------------------  CONFIGURATION  --------------------*/

$config['hostname'] = "127.0.0.1"; //mettez ici le serveur MySQL (souvent 'localhost')
$config['username'] = "root"; //login et...
$config['password'] = "";     //...mot de passe de la base
$config['database'] = "test"; //mettez ici le nom de votre base
$config['table'] = "divx"; //nom de la table mysql, d�fini lors de l'exportation dans AMC

$config['file'] = "images/divx.xml"; //votre fichier AMC au format XML
//note : je vous conseille de le stocker dans le dossier contenant les images, car c'est ce qu'AMC fait...

$config['images'] = "images"; //votre dosiers d'images (relatif au script)

//le titre de votre liste :
$config['titre'] 	= "Ma liste de films";
//sous-titre :
$config['soustitre'] 	= "bonne consultation ;-)";
//votre nom/pseudo :
$config['vous'] 	= "moi";
//votre e-mail :
$config['contact'] 	= "moi@chezmoi.fr";
//page de traitement du formulaire (envoy� par POST) :
$config['dest_form'] 	= "votreScriptMail.php";

/*---------------------  NE PAS TOUCHER  -------------------*/

mysql_connect($config['hostname'], $config['username'], $config['password']) or die(mysql_error());
mysql_select_db($config['database']);

?>