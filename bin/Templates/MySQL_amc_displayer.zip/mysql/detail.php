<?php
include("inc.config.php");
$id=$_GET['id']; //champ Number
$result = mysql_query("SELECT * FROM `".$config['table']."` WHERE Number='$id'") or die(mysql_error());
$num = mysql_num_fields($result);
$row = mysql_fetch_assoc($result);
?>
<html><head><link href="style.css" rel="stylesheet" type="text/css" />
<title>Fiche film - <?=$row['TranslatedTitle']?></title>
</head><body><div align="center"><h2>Fiche film</h2></div>
<table class="blk" border="1" cellspacing="0" cellpadding="5">
  <tr>
    <td nowrap="nowrap">R�f. : <strong>DX<?=$row['Number']?></strong> (<?=@$row['Disks']?> CD)</td>
    <td colspan="2">
    <strong><?=@$row['TranslatedTitle']?></strong>
    <?=strtolower(@$row['OriginalTitle'])!=strtolower(@$row['TranslatedTitle'])?" (Titre original : ".@$row['OriginalTitle'].")":""?>
    </td>
  </tr>
  <tr>
    <td rowspan="6"><div align="center"><?=$row['Rating']>0?"<img src=\"ico/appr".floor(($row['Rating']-1)/2).".gif\" alt=\"Qualit� de l'image et du son\">":""?></div><br /><?=$row['Picture']!=""?" <img src=\"".$config['images']."/".$row['Picture']."\"> ":""?>
    <p>Format : <?=$row['VideoFormat']?><br />Dur�e : <?=$row['Length']?> min.</p></td>
    <td>Genre : </td>
    <td><?=$row['Category']?>&nbsp;</td>
  </tr>
  <tr>
    <td>Origine : </td>
    <td><?=$row['Country']?>&nbsp;</td>
  </tr>
  <tr>
    <td>Acteurs : </td>
    <td><?=$row['Actors']?>&nbsp;</td>
  </tr>
  <tr>
    <td nowrap="nowrap">R�alisateur(s) : </td>
    <td><?=$row['Director']?>&nbsp;</td>
  </tr>
  <tr>
    <td colspan="2" rowspan="2"><i><?=$row['Comments']!=""?$row['Comments'].". ":""?></i><?=str_replace("|", "<br />", $row['Description'])?><br /><a href="<?=$row['Url']?>" target="_blank"><?=$row['Url']?></a>&nbsp;</td>
  </tr>
</table></body></html>