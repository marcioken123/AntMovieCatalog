<?php
include("inc.config.php");
$retour = "<a href=\"index.php\">Retour</a>";
$table = $config['table'];
$file = $config['file'];

if(!function_exists("simplexml_load_file")){
	echo "SimpleXML n'est pas install� sur votre syst�me. Mettez � jour PHP dans sa version 5 minimum pour r�soudre le probl�me.<br />".$retour;
	exit();
}

$debut = explode(" ",microtime());
$debut = $debut[1]+$debut[0];
$report = "<pre>$retour<br />";

$report.= "Chargement de la configuration... ";
$report.= "OK.<br />";

$requete = "DROP TABLE IF EXISTS $table";
$report.= "Ex�cution : '$requete'... ";
mysql_query($requete) or die($report.mysql_error());
$report.= "OK.<br />";

$requete = "CREATE TABLE $table (Number INT NOT NULL, MediaLabel TEXT, Borrower TEXT, Rating INT, OriginalTitle TEXT, TranslatedTitle TEXT, Director TEXT, Producer TEXT, Country TEXT, Category TEXT, Year INT, Length INT, Actors TEXT, Url TEXT, Description TEXT, Comments TEXT, VideoFormat TEXT, Languages TEXT, SubTitles TEXT, Disks INT, Picture TEXT, Checked TEXT, Date TEXT)";
$report.= "Ex�cution : '$requete'... ";
mysql_query($requete) or die($report.mysql_error());
$report.= "OK.<br />";

$report.= "Chargement du fichier '$file'... ";
$amc = simplexml_load_file($file);
$report.= "OK.<br />";


$report.= "Parsing XML : Lecture ligne par ligne et insertion dans la base... <br />";

foreach($amc->Catalog->Contents->Movie as $movie) {
	$query = "INSERT INTO $table (";
	$dedans = false;
	foreach($movie->attributes() as $a => $b) {
		if($dedans){
			$query.=", ";
		}
    		$query.= $a;
    		$dedans = true;
    	}
    	$query.= ") VALUES (";
    	$dedans = false;
	foreach($movie->attributes() as $a => $b) {
		if($dedans){
			$query.=", ";
		}
    		$query.= "'".utf8_decode(addslashes($b))."'";
    		$dedans = true;
    	}
    	$query.= ")";
    	$report.= "\tEx�cution : '$query'... ";
    	mysql_query($query) or die($report.mysql_error());
	$report.= "OK.<br />";
} 


$fin = explode(" ",microtime()); 
$fin = $fin[1]+$fin[0]; 
$temps_passe = number_format($fin-$debut, 2, ',', '');
$report.= "Actualisation termin�e ($temps_passe secondes).<br />$retour";
@header("location: index.php?refresh=... effectu�  ($temps_passe s).");
?>