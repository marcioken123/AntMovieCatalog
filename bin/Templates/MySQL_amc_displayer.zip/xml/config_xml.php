<?php
/*----------------------------------------------------*/
/*          SCRIPT FAIT PAR Antoine Rousseau          */
/*               mout85@gmail.com                     */
/*----------------------------------------------------*/


//votre fichier AMC au format XML :
//note : je vous conseille de le stocker dans le dossier contenant les images, car c'est ce qu'AMC fait...
$config['file'] 	= "images/divx.xml";

//votre dosiers d'images (relatif au script) :
$config['images'] 	= "images";

//le titre de votre liste :
$config['titre'] 	= "Ma liste de films";

//sous-titre :
$config['soustitre'] 	= "bonne consultation ;-)";

//votre nom/pseudo :
$config['vous'] 	= "moi";

//votre e-mail :
$config['contact'] 	= "moi@chezmoi.fr";

//page de traitement du formulaire (envoy� par POST) :
$config['dest_form'] 	= "votreScriptMail.php";

?>