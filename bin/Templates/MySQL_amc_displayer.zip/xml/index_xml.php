<?php
include("config_xml.php");
if(!function_exists("simplexml_load_file"))
  exit("SimpleXML n'est pas install� sur votre syst�me. Mettez � jour PHP pour r�soudre le probl�me.");
?>
<html>
<head>
<title><?=$config['titre']?></title>
<link href="style.css" rel="stylesheet" type="text/css" />
<script type="text/javascript">
function test_mail(){
	if(document.emprunts.nom.value==""){
		alert('Veuillez indiquer votre nom complet.');
		return false;
	}else{
		if(document.emprunts.email.value==""){
			alert('Veuillez indiquer votre adresse e-mail.');
			return false;
		}
	}
	return true;
}
function pop(id){
	window.open('detail_xml.php?id='+id,'D�tails','width=750,height=480,resizable=yes,scrollbars=yes');
}
</script>
</head>
<body>

<p class="title" ><?=$config['titre']?></p>

<p class="subtitle"><?=$config['soustitre']?><br/>&nbsp;</p>

<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td>
      Pour toute suggestion, <a href="mailto:<?=$config['contact']?>">contactez-moi</a>.<br />
      Pour emprunter, faites votre choix puis voyez <a href="#foot">en bas</a>.<br />
      Pour plus de d�tails sur un film, cliquez sur son titre.
    </td>
    <td align="right">
      <form method="get" action="index_xml.php" name="search">
        <input type="text" name="query" size="30">
        <select name="champ">
          <option value="TranslatedTitle">Titre traduit</option>
          <option value="OriginalTitle">Titre original</option>
          <option value="Description">R�sum�</option>
          <option value="Borrower">Emprunteur</option>
          <option value="Category">Genre</option>
          <option value="Country">Origine</option>
          <option value="Actors">Acteurs</option>
          <option value="Director">R�alisateur(s)</option>
        </select>
        <input type="submit" name="submit" value="Rechercher" onClick="return test_search()">
      </form>
    </td>
  </tr>
</table>

<form name="emprunts" method="post" action="<?=$config['dest_form']?>">

<?php 
if(isset($_GET['query']) && isset($_GET['champ']))
	echo "<p align=\"center\" style=\"color: red; \">Recherche de \"<b>".htmlspecialchars($_GET['query'])."</b>\" dans <b>".$_GET['champ']."</b> :</p>"; 
else 
	echo "<br />";  
?>


<table class="blk" border="1" cellspacing="0" cellpadding="5">
  <tr>
    <td class="blk" nowrap>
      R�f.
    </td>
    <td class="blk" nowrap>
      Titre fran�ais (titre original)
    </td>
    <td class="blk" nowrap>
      Emprunteur
    </td>
    <td class="blk" nowrap width="2%">
      Genre
    </td>
  </tr>

<?php 

$amc = simplexml_load_file($config['file']);

$i=0;
foreach($amc->Catalog->Contents->Movie as $row2) {
   $i++;
   foreach($row2->attributes() as $a => $b)
      $t[$i][$a] = utf8_decode($b);
}

//tri ici de $t[][]

foreach($t as $row){
  
  if(isset($_GET['query']) && !empty($_GET['query'])){
  	if(!eregi($_GET['query'],@$row[$_GET['champ']]))
  		continue;
  }

  ?>

  <tr>
    <td width="10%">
      <input 
        type="checkbox" 
        name="emprunt[]" 
        value="<?="DX".$row['Number']." : ".$row['TranslatedTitle']." (".$row['OriginalTitle'].")"?>"
        <?=(isset($row['Borrower'])?" disabled=\"true\"":"")?>
      >
      DX<?=$row['Number']?>
    </td>
    <td width="60%">
      <strong><a href="javascript:pop(<?=$row['Number']?>)"><?=$row['TranslatedTitle']?></a></strong>
      <?=strtolower($row['OriginalTitle'])!=strtolower($row['TranslatedTitle'])?" (".$row['OriginalTitle'].")":""?>
    </td>
    <td style="color: red" width="15%">
      <?=isset($row['Borrower'])?str_replace("Pas encore grav�","<i style=\"color: #AAAAAA\">Pas encore grav�</i>",
			        str_replace("Inconnu","<i style=\"color: #AAAAAA\">Inconnu</i>",$row['Borrower'])):"&nbsp;"?>
    </td>
    <td width="15%" nowrap="nowrap">
      <?=isset($row['Category'])?$row['Category']:"&nbsp;"?>
    </td>
  </tr>

  <?php

}

?>

</table>
<p>
  <a name="foot"><strong>Total : <?=count($t)?> films.</strong></a>
</p>
<p>
  Pour emprunter, cochez les films d�sir�s, remplissez les deux champs ci-dessous puis validez.
</p>
<table border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td>
      Votre nom complet : 
    </td>
    <td>
      <input type="text" name="nom">
    </td>
  </tr>
  <tr>
    <td>
      Votre e-mail : 
    </td>
    <td>
      <input type="text" name="email">
    </td>
  </tr>
  <tr>
    <td>
      Commentaires (ou, quand, comment,...) : 
    </td>
    <td>
      <input type="text" name="commentaires" size="50">
    </td>
  </tr>
</table>
<input type="submit" value="Demander � emprunter la s�lection" onClick="javascript:return test_mail();">

</form>

<p align="right">
  <a href="#top">Remonter au d�but</a>
</p>
<p>
  Liste �dit�e par <a href="mailto:<?=$config['contact']?>"><?=$config['vous']?></a>
</p>
<p style="font-size: 11px; text-align: center;">
  Script by <a href="http://www.mout.fr" target="_blank">MOutOn Productions</a>
   | Special thanks to <a href="http://www.antp.be/software/moviecatalog/fr" target="_blank">Ant Movie Catalog</a>
  <br />
  <br />
</p>
</body>
</html>
