Anv�nd "full" och "individual" i mappen "templates" n�r du exportar till HTML.

Exportera "full" till mappen film-listan/sidan och ers�tt filen "lista.html".
Den h�r mallen skapar listan i v�nster ram.

Exportera "individual" till mappen film-listan/filmer och spara som "film". Det �r viktigt
att du exporterar mallen "individual" som "film". Annars funkar det inte. G� in i "filmer" 
mappen och kolla s� att filerna �r d�pta: film_1, film_2 o.s.v.

Det �r m�jligt att du m�ste in och mecka med inst�llningarna i programmet om filerna inte �r
d�pta enligt ovan.
Kolla s� att du har f�ljande inst�llningar under Tools->Preferences:
Export->Individual pages and pictures filename style->Exported filename + Movie number

Har du detta inst�llt ska det funka...                                      


�ppna "index.html" i mappen "film-listan" f�r att �ppna din film-lista.



/Tobo