H�r ska de individuella sidorna placeras.

G� in i "filmer" mappen och kolla s� att filerna �r d�pta: film_1, film_2 o.s.v.

Det �r m�jligt att du m�ste in och mecka med inst�llningarna i programmet om filerna inte �r
d�pta enligt ovan.
Kolla s� att du har f�ljande inst�llningar under Tools->Preferences:
Export->Individual pages and pictures filename style->Exported filename + Movie number

Har du detta inst�llt ska det funka...


/Tobo